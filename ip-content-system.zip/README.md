# IP 内容全流程自动化生产系统

多 Agent 协作的内容创作全流程自动化系统，覆盖选题调研、内容生成、分发互动全链路。

## 系统架构

```
┌──────────────────────────────────────────────────────────┐
│                    可视化面板 (React)                     │
├──────────────────────────────────────────────────────────┤
│                     API 层 (FastAPI)                     │
├──────────────────────────────────────────────────────────┤
│         ┌──────────┐ ┌──────────┐ ┌──────────┐         │
│         │ 选题调研  │ │ 内容生成  │ │ 分发互动  │         │
│         │  Agent   │ │  Agent   │ │  Agent   │         │
│         └──────────┘ └──────────┘ └──────────┘         │
│                    Orchestrator                         │
├──────────────────────────────────────────────────────────┤
│              LiteLLM (OpenAI / Claude / ...)             │
├──────────────────────────────────────────────────────────┤
│            PostgreSQL + Redis                            │
└──────────────────────────────────────────────────────────┘
```

## 三大核心 Agent

### 1. 选题调研 Agent (TopicResearchAgent)
- 热点趋势分析
- 用户需求长链推理
- 竞品内容缺口分析
- 差异化选题生成
- 热度/竞争度评估

### 2. 内容生成 Agent (ContentGenerationAgent)
- 短视频脚本 (Hook→痛点→干货→CTA)
- 图文笔记/种草文案
- 直播话术
- 深度文章
- 多平台自动适配

### 3. 分发互动 Agent (DistributionAgent)
- 多平台内容发布
- 评论情感分析
- AI 拟真回复生成
- 最佳发布时间建议
- 互动数据分析

## 快速启动

### 方式一：Docker 部署（推荐）

```bash
# 1. 复制环境变量
cp .env.example .env
# 编辑 .env 填入 LLM API Key

# 2. 启动所有服务
docker compose up -d

# 3. 访问前端
open http://localhost
```

### 方式二：本地开发

```bash
# 后端
cd backend
pip install -r requirements.txt
# 确保 PostgreSQL 已启动
uvicorn app.main:app --reload

# 前端
cd frontend
npm install
npm run dev
```

## 环境变量

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `LLM_PROVIDER` | LLM 提供商 | `openai` |
| `LLM_MODEL` | 模型名称 | `gpt-4o` |
| `LLM_API_KEY` | API 密钥 | - |
| `LLM_API_BASE` | API 地址 | - |
| `DATABASE_URL` | 数据库连接 | `postgresql+asyncpg://postgres:postgres@localhost:5432/ip_content_system` |

## 技术栈

- **后端**: Python 3.12, FastAPI, SQLAlchemy (async), LiteLLM
- **前端**: React 18, TypeScript, Tailwind CSS, Recharts
- **数据库**: PostgreSQL 16, Redis
- **部署**: Docker, Docker Compose
