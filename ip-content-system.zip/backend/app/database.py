"""Async PostgreSQL database session management."""

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase

from app.config import settings

engine = create_async_engine(
    settings.database_url,
    echo=settings.debug,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
)

async_session_factory = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


class Base(DeclarativeBase):
    """Base class for all SQLAlchemy ORM models."""
    pass


async def get_db() -> AsyncSession:
    """Dependency that yields an async database session."""
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db():
    """Create all tables (for development). Use Alembic in production."""
    async with engine.begin() as conn:
        from app.models.topic import Topic  # noqa
        from app.models.content import Content, ContentVariant  # noqa
        from app.models.comment import Comment, ReplyTemplate  # noqa
        from app.models.platform_account import PlatformAccount, PublishedContent  # noqa
        from app.models.workflow import WorkflowRun, AgentLog  # noqa
        await conn.run_sync(Base.metadata.create_all)
