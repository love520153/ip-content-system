"""Application configuration using pydantic-settings."""

from pathlib import Path
from typing import Optional

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Database
    database_url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/ip_content_system"

    # LLM Configuration
    llm_provider: str = "openai"
    llm_model: str = "gpt-4o"
    llm_api_key: str = ""
    llm_api_base: Optional[str] = None
    llm_max_tokens: int = 4096
    llm_temperature: float = 0.7

    # Fallback LLM
    llm_fallback_provider: Optional[str] = None
    llm_fallback_model: Optional[str] = None
    llm_fallback_api_key: Optional[str] = None

    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = True
    cors_origins: str = "http://localhost:5173,http://localhost:3000"

    # Redis / Task Queue
    redis_url: str = "redis://localhost:6379/0"

    # Platform API Keys
    douyin_app_id: Optional[str] = None
    douyin_app_secret: Optional[str] = None
    douyin_access_token: Optional[str] = None

    bilibili_app_id: Optional[str] = None
    bilibili_app_secret: Optional[str] = None
    bilibili_access_token: Optional[str] = None

    xiaohongshu_app_id: Optional[str] = None
    xiaohongshu_app_secret: Optional[str] = None
    xiaohongshu_access_token: Optional[str] = None

    wechat_app_id: Optional[str] = None
    wechat_app_secret: Optional[str] = None

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",")]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
