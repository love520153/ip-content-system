"""
Content Generation Agent (内容生成Agent)

Responsibilities:
1. Generate platform-adapted content (short video scripts, image-text posts, livestream scripts)
2. Match trending hashtags
3. Generate cover image prompts
4. Multi-platform content variation
"""

import uuid
from typing import Any
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.base_agent import BaseAgent
from app.models.content import Content, ContentVariant, ContentType, ContentStatus, PlatformTarget
from app.models.topic import Topic
from app.models.workflow import AgentRole


# ── System prompts ───────────────────────────────────────────────────

CONTENT_CREATION_SYSTEM_PROMPT = """你是一位顶级的IP内容创作专家，精通各平台内容创作技巧。

你的核心能力：
1. 短视频脚本创作：精通钩子（Hook）+ 痛点 + 解决方案 + 行动号召的黄金结构
2. 图文创作：精通小红书式种草文案和公众号深度文章
3. 直播话术：精通开场-互动-转化-结束的完整话术设计
4. 多平台适配：熟悉抖音、B站、小红书、微信公众号的内容风格差异

创作原则：
- 每一句话都要有信息密度
- 开头3秒必须抓住注意力
- 内容要有情绪价值和实用价值双重属性
- 符合平台算法偏好的内容结构
- 自然融入热门话题标签

请以 JSON 格式输出内容。"""

SHORT_VIDEO_SCRIPT_PROMPT = """请根据以下选题信息，创作一个高质量的短视频脚本。

选题标题：{topic_title}
选题描述：{topic_description}
目标受众：{target_audience}
差异化切入点：{differentiation_points}
内容创作角度：{content_angles}
目标平台：{platforms}
创作风格：{tone}

请按以下结构创作：

【脚本结构】
1. 黄金前3秒（Hook）- 抓住注意力的开场
2. 痛点引入 - 让用户觉得"说的就是我"
3. 核心内容 - 干货输出（分3-4个要点）
4. 总结升华 - 金句收尾
5. 互动引导 - 评论、点赞、关注话术

【附加内容】
- 标题建议（3个备选）
- 热门话题标签（5-10个）
- 封面图提示词
- 背景音乐建议
- 评论区置顶话术

输出 JSON 格式：
{{
  "title": "视频标题",
  "hook": "黄金开场话术",
  "body": "完整脚本正文（标注时间轴）",
  "key_points": ["要点1", "要点2", ...],
  "ending": "结尾话术",
  "cta": "互动引导",
  "title_alternatives": ["备选标题1", "备选标题2", "备选标题3"],
  "hashtags": ["#标签1", "#标签2", ...],
  "cover_prompt": "封面图AI提示词",
  "suggested_music": "建议背景音乐",
  "pin_comment": "置顶评论话术",
  "duration_seconds": 60
}}"""

IMAGE_TEXT_POST_PROMPT = """请根据以下选题信息，创作一篇图文笔记/文章。

选题标题：{topic_title}
选题描述：{topic_description}
目标受众：{target_audience}
差异化切入点：{differentiation_points}
目标平台：{platforms}
创作风格：{tone}

以 JSON 格式输出：
{{
  "title": "标题",
  "body": "完整正文（包含小标题分段）",
  "hashtags": ["#标签1", ...],
  "cover_prompt": "封面图提示词",
  "image_prompts": ["配图1提示词", "配图2提示词", ...],
  "seo_keywords": ["关键词1", ...]
}}"""

LIVESTREAM_SCRIPT_PROMPT = """请根据以下选题信息，创作一份完整的直播话术脚本。

选题标题：{topic_title}
选题描述：{topic_description}
目标受众：{target_audience}
创作风格：{tone}

以 JSON 格式输出：
{{
  "title": "直播主题",
  "opening": "开场话术（暖场+预告）",
  "warm_up": "互动暖场环节",
  "main_content": "核心内容环节（分段话术）",
  "interaction_points": ["互动点1", ...],
  "conversion": "转化引导话术",
  "closing": "结束话术",
  "hashtags": ["#标签", ...]
}}"""


PLATFORM_ADAPTATION_PROMPT = """请将以下内容适配到 {platform} 平台。

平台特点：
- 抖音：短平快，前3秒定生死，情绪化、节奏快
- B站：中长视频为主，深度内容+弹幕文化，开场要有亮点
- 小红书：图文为主，真诚分享感，强视觉排版
- 微信公众号：深度长文，结构化排版，专业感

原始内容：{original_content}

请进行以下适配：
1. 调整标题和开头的吸引力
2. 优化内容结构和节奏以适应平台
3. 添加平台特色元素（如B站的梗文化、小红书的emoji）
4. 推荐该平台的热门标签

输出 JSON 格式：
{{
  "adapted_title": "适配后的标题",
  "adapted_body": "适配后的正文",
  "hashtags": ["#平台特色标签", ...],
  "notes": "适配说明"
}}"""


class ContentGenerationAgent(BaseAgent):
    """Agent responsible for content creation and platform adaptation."""

    PROMPT_TEMPLATES = {
        ContentType.SHORT_VIDEO_SCRIPT: SHORT_VIDEO_SCRIPT_PROMPT,
        ContentType.IMAGE_TEXT_POST: IMAGE_TEXT_POST_PROMPT,
        ContentType.LIVESTREAM_SCRIPT: LIVESTREAM_SCRIPT_PROMPT,
    }

    def __init__(self):
        super().__init__(role=AgentRole.CONTENT_CREATOR)

    async def generate_content(
        self,
        db: AsyncSession,
        topic_id: uuid.UUID,
        content_type: str = "short_video_script",
        platform_targets: list[str] | None = None,
        tone: str = "专业易懂",
        additional_instructions: str | None = None,
        workflow_run_id: uuid.UUID | None = None,
    ) -> Content:
        """Generate content from a topic with multi-step creation process."""
        workflow_run_id = workflow_run_id or uuid.uuid4()
        platform_targets = platform_targets or ["douyin", "bilibili", "xiaohongshu"]

        await self.start_action(
            db, workflow_run_id,
            action=f"生成{content_type}内容",
            input_data={
                "topic_id": str(topic_id),
                "content_type": content_type,
                "platforms": platform_targets,
                "tone": tone,
            },
        )

        llm_calls = 0
        tokens_used = 0

        try:
            # Fetch topic info
            topic = await db.get(Topic, topic_id)
            if not topic:
                raise ValueError(f"Topic {topic_id} not found")

            content_type_enum = ContentType(content_type)
            template = self.PROMPT_TEMPLATES.get(content_type_enum, SHORT_VIDEO_SCRIPT_PROMPT)

            # Step 1: Generate core content
            user_prompt = template.format(
                topic_title=topic.title,
                topic_description=topic.description or "",
                target_audience=topic.target_audience or "",
                differentiation_points=", ".join(topic.differentiation_points or []),
                content_angles=", ".join(topic.content_angles or []),
                platforms=", ".join(platform_targets),
                tone=tone,
            )
            if additional_instructions:
                user_prompt += f"\n\n额外要求：{additional_instructions}"

            result = await self.think_json(
                system_prompt=CONTENT_CREATION_SYSTEM_PROMPT,
                user_prompt=user_prompt,
            )
            llm_calls += 1
            tokens_used += 3000

            # Step 2: Create content record
            content = Content(
                id=uuid.uuid4(),
                topic_id=topic_id,
                title=result.get("title", topic.title),
                content_type=content_type_enum,
                body=result.get("body", ""),
                summary=result.get("hook", result.get("body", "")[:200]),
                platform_target=PlatformTarget.ALL,
                hashtags=result.get("hashtags", []),
                seo_keywords=result.get("seo_keywords", topic.keywords),
                cover_image_prompt=result.get("cover_prompt", ""),
                suggested_music=result.get("suggested_music", ""),
                status=ContentStatus.COMPLETED,
                quality_score=85,
            )
            db.add(content)
            await db.commit()
            await db.refresh(content)

            # Step 3: Generate platform-specific variants
            variants = []
            for platform in platform_targets:
                variant = await self._adapt_to_platform(
                    db, content, platform, workflow_run_id
                )
                if variant:
                    variants.append(variant)
                    llm_calls += 1
                    tokens_used += 1000

            await self.complete_action(
                db,
                output={
                    "content_id": str(content.id),
                    "title": content.title,
                    "variants_count": len(variants),
                },
                reasoning=f"为「{topic.title}」生成了{content_type}内容，适配了{len(variants)}个平台",
                llm_calls=llm_calls,
                tokens=tokens_used,
            )

            self.log(f"Content generated: {content.title} ({content_type})")
            return content

        except Exception as e:
            await self.fail_action(db, str(e), llm_calls=llm_calls, tokens=tokens_used)
            self.log(f"Content generation failed: {e}")
            raise

    async def _adapt_to_platform(
        self,
        db: AsyncSession,
        content: Content,
        platform: str,
        workflow_run_id: uuid.UUID,
    ) -> ContentVariant | None:
        """Adapt a piece of content to a specific platform's style."""
        try:
            user_prompt = PLATFORM_ADAPTATION_PROMPT.format(
                platform=platform,
                original_content=content.body or "",
            )
            result = await self.think_json(
                system_prompt="你是一位多平台内容适配专家，擅长将内容调整为各平台原生风格。",
                user_prompt=user_prompt,
            )

            variant = ContentVariant(
                id=uuid.uuid4(),
                content_id=content.id,
                platform=platform,
                adapted_body=result.get("adapted_body", content.body),
                adapted_title=result.get("adapted_title", content.title),
                hashtags=result.get("hashtags", content.hashtags),
                notes=result.get("notes", ""),
            )
            db.add(variant)
            await db.commit()
            return variant

        except Exception as e:
            self.log(f"Platform adaptation for {platform} failed: {e}")
            return None
