"""
Topic Research Agent (选题调研Agent)

Responsibilities:
1. Analyze trending topics from platforms
2. Perform long-chain reasoning on user preferences
3. Generate topic lists with differentiation directions
4. Estimate trend scores and competition levels
"""

import uuid
from datetime import datetime
from typing import Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.agents.base_agent import BaseAgent
from app.models.topic import Topic, TopicStatus, TopicSource
from app.models.workflow import AgentRole


# ── System prompts ───────────────────────────────────────────────────

TOPIC_ANALYSIS_SYSTEM_PROMPT = """你是一位顶尖的内容策略分析师和趋势洞察专家。你的核心能力是：
1. 深度分析内容赛道趋势，识别蓝海机会
2. 从用户视角进行长链推理，挖掘真实需求
3. 生成具有差异化竞争力的选题建议
4. 评估选题的流量潜力和竞争环境

每次分析请遵循以下框架：
- 先用 3 轮链式推理（Chain-of-Thought）分析趋势方向
- 然后生成具体的选题清单
- 最后为每个选题提供差异化创作建议

请以 JSON 格式输出你的分析结果。"""

TOPIC_GENERATION_PROMPT = """请为以下内容赛道进行选题分析：

赛道/领域：{niche}
核心关键词：{keywords}
目标平台：{platforms}
需要生成的选题数量：{count}

请按以下步骤进行深度分析：

【步骤1：赛道趋势分析】
分析该赛道的当前热门趋势、用户核心痛点、搜索增长方向。

【步骤2：用户需求长链推理】
从用户视角出发：用户为什么需要这类内容？他们在什么场景下消费？
他们的深层需求是什么？现有内容满足了哪些、遗漏了哪些？

【步骤3：竞品内容分析】
分析该赛道已有头部内容的特征，找到内容同质化严重的区域，
识别出尚未被充分满足的用户需求。

【步骤4：生成差异化选题】
基于以上分析，生成 {count} 个具备差异化竞争力的选题。
每个选题需要包含：
- title: 选题标题（要吸引人、有差异化）
- description: 选题描述和内容方向
- keywords: 3-5个相关关键词
- category: 内容分类
- trend_score: 趋势热度评分 (0-100)
- competition_level: 竞争程度 (low/medium/high)
- estimated_views: 预估流量 (low/medium/high)
- differentiation_points: 2-3个差异化切入点
- target_audience: 目标受众描述
- content_angles: 2-3个内容创作角度
- platform_suitability: 每个平台（抖音/B站/小红书）的适配建议

请以 JSON 格式输出，格式如下：
{{
  "market_analysis": {{
    "trends": "赛道趋势分析总结",
    "user_pain_points": "用户核心痛点",
    "content_gaps": "内容缺口分析"
  }},
  "topics": [...]
}}
"""


class TopicResearchAgent(BaseAgent):
    """Agent responsible for topic research and trend analysis."""

    def __init__(self):
        super().__init__(role=AgentRole.TOPIC_RESEARCHER)

    async def research_topics(
        self,
        db: AsyncSession,
        niche: str,
        keywords: list[str] | None = None,
        platforms: list[str] | None = None,
        count: int = 5,
        workflow_run_id: uuid.UUID | None = None,
    ) -> list[Topic]:
        """Execute a full topic research cycle.

        This performs multi-step reasoning:
        1. Trend analysis → 2. User need deep-dive → 3. Gap analysis → 4. Topic generation
        """
        workflow_run_id = workflow_run_id or uuid.uuid4()
        keywords_str = ", ".join(keywords) if keywords else niche
        platforms_str = ", ".join(platforms) if platforms else "抖音, B站, 小红书"

        await self.start_action(
            db, workflow_run_id,
            action="选题调研分析",
            input_data={
                "niche": niche,
                "keywords": keywords,
                "platforms": platforms,
                "count": count,
            },
        )

        llm_calls = 0
        tokens_used = 0

        try:
            # Step 1-4: Full analysis via LLM with chain-of-thought
            user_prompt = TOPIC_GENERATION_PROMPT.format(
                niche=niche,
                keywords=keywords_str,
                platforms=platforms_str,
                count=count,
            )

            result = await self.think_json(
                system_prompt=TOPIC_ANALYSIS_SYSTEM_PROMPT,
                user_prompt=user_prompt,
            )
            llm_calls += 1
            tokens_used += 2000  # Approximate

            self.log(f"Analysis complete: {len(result.get('topics', []))} topics generated")

            # Persist topics to database
            topics = []
            for topic_data in result.get("topics", []):
                topic = Topic(
                    id=uuid.uuid4(),
                    title=topic_data.get("title", ""),
                    description=topic_data.get("description", ""),
                    keywords=topic_data.get("keywords", []),
                    category=topic_data.get("category", niche),
                    niche=niche,
                    trend_score=float(topic_data.get("trend_score", 50)),
                    competition_level=topic_data.get("competition_level", "medium"),
                    estimated_views=topic_data.get("estimated_views", 0),
                    source=TopicSource.AI_GENERATED,
                    differentiation_points=topic_data.get("differentiation_points", []),
                    target_audience=topic_data.get("target_audience", ""),
                    content_angles=topic_data.get("content_angles", []),
                    platform_suitability=topic_data.get("platform_suitability", {}),
                    status=TopicStatus.READY,
                )
                db.add(topic)
                topics.append(topic)

            await db.commit()
            for t in topics:
                await db.refresh(t)

            # Complete action
            await self.complete_action(
                db,
                output={"topics_count": len(topics), "topic_ids": [str(t.id) for t in topics]},
                reasoning=result.get("market_analysis", {}).get("trends", ""),
                llm_calls=llm_calls,
                tokens=tokens_used,
            )

            self.log(f"Successfully created {len(topics)} topics for niche: {niche}")
            return topics

        except Exception as e:
            await self.fail_action(db, str(e), llm_calls=llm_calls, tokens=tokens_used)
            self.log(f"Topic research failed: {e}")
            raise

    async def analyze_trend_evolution(
        self,
        db: AsyncSession,
        niche: str,
        days: int = 7,
    ) -> dict[str, Any]:
        """Analyze how trends in a niche have evolved over time."""
        # Query existing topics in this niche
        stmt = select(Topic).where(
            Topic.niche == niche,
            Topic.created_at >= datetime.utcnow().timestamp() - days * 86400,
        ).order_by(Topic.created_at.desc())
        result = await db.execute(stmt)
        existing_topics = result.scalars().all()

        return {
            "niche": niche,
            "period_days": days,
            "total_topics_analyzed": len(existing_topics),
            "avg_trend_score": (
                sum(t.trend_score or 0 for t in existing_topics) / len(existing_topics)
                if existing_topics else 0
            ),
            "top_categories": self._extract_categories(existing_topics),
        }

    def _extract_categories(self, topics: list[Topic]) -> list[dict]:
        """Extract category distribution from topics."""
        from collections import Counter
        counter = Counter(t.category for t in topics if t.category)
        return [
            {"category": cat, "count": cnt}
            for cat, cnt in counter.most_common(10)
        ]
