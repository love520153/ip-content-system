"""
Distribution & Interaction Agent (分发与互动Agent)

Responsibilities:
1. Auto-adapt content format for different platforms
2. Publish content to platforms
3. Fetch & analyze user comments
4. Generate highly realistic reply scripts
5. Maintain fan interaction quality
"""

import uuid
from typing import Any
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_

from app.agents.base_agent import BaseAgent
from app.models.content import Content
from app.models.comment import Comment, ReplyTemplate, CommentSentiment, ReplyStatus
from app.models.platform_account import PlatformAccount, PublishedContent, PublishStatus
from app.models.workflow import AgentRole
from app.utils.platform_adapters import get_adapter


# ── System prompts ───────────────────────────────────────────────────

COMMENT_ANALYSIS_SYSTEM_PROMPT = """你是一位社群互动管理专家，擅长粉丝互动和评论管理。

你的核心能力：
1. 精准识别评论的情感倾向和真实意图
2. 区分普通评论、深度提问、负面反馈和潜在危机
3. 为每条评论生成高拟真度的回复话术
4. 保持账号人设一致性（语气、风格、价值观）

回复话术原则：
- 自然真实，避免机器人感
- 有情绪价值，让粉丝感到被重视
- 根据评论类型采取不同策略：
  * 正面评论：感谢 + 延伸互动
  * 提问评论：专业解答 + 引导关注
  * 负面评论：共情 + 解决 + 私信引导
  * 建议评论：感谢 + 认可 + 讨论

请以 JSON 格式输出回复建议。"""

REPLY_GENERATION_PROMPT = """请为以下评论生成回复话术：

评论原文：{comment_text}
评论情感倾向：{sentiment}
评论作者：{author_name}
所属内容标题：{content_title}
账号人设风格：{account_tone}

要求：
- 回复要自然真实，像真人运营者
- 长度控制在 20-100 字之间
- 体现账号的人设特点
- 对于提问类评论，要提供有价值的回答
- 适当运用平台特色（如表情包、梗等）

请提供 2 个不同风格的备选回复。

输出 JSON：
{{
  "sentiment_analysis": "情感分析结论",
  "reply_priority": "high/medium/low",
  "suggested_replies": [
    {{"text": "回复1", "reason": "选择理由", "tone": "回复语气"}},
    {{"text": "回复2", "reason": "选择理由", "tone": "回复语气"}}
  ],
  "should_reply": true,
  "notes": "互动建议备注"
}}"""

SCHEDULING_PROMPT = """请根据以下信息分析最佳发布时间：

内容类型：{content_type}
目标平台：{platforms}
目标受众画像：{audience_profile}
账号历史数据：{account_stats}

分析每个平台的最佳发布时间（精确到小时），并给出发布策略建议。

输出 JSON：
{{
  "schedule": {{
    "douyin": {{"best_time": "18:00-21:00", "recommended_day": "周五", "reason": "..."}},
    "bilibili": {{"best_time": "12:00-14:00", "recommended_day": "周六", "reason": "..."}},
    "xiaohongshu": {{"best_time": "07:00-09:00", "recommended_day": "周日", "reason": "..."}}
  }},
  "strategy": "整体发布策略建议",
  "frequency": "建议发布频率"
}}"""


class DistributionAgent(BaseAgent):
    """Agent responsible for content publishing, comment management, and interaction."""

    def __init__(self):
        super().__init__(role=AgentRole.DISTRIBUTOR)

    async def publish_content(
        self,
        db: AsyncSession,
        content_id: uuid.UUID,
        platform_accounts: list[PlatformAccount] | None = None,
        auto_publish: bool = False,
        workflow_run_id: uuid.UUID | None = None,
    ) -> list[PublishedContent]:
        """Publish content to target platforms.

        Args:
            db: Database session
            content_id: ID of the content to publish
            platform_accounts: List of platform accounts to publish to.
                              If None, fetches all active accounts.
            auto_publish: If True, actually publishes. If False, creates draft records.
            workflow_run_id: Optional workflow run ID for tracking.
        """
        workflow_run_id = workflow_run_id or uuid.uuid4()

        await self.start_action(
            db, workflow_run_id,
            action="分发内容到平台",
            input_data={
                "content_id": str(content_id),
                "auto_publish": auto_publish,
            },
        )

        llm_calls = 0
        tokens_used = 0

        try:
            # Fetch content
            content = await db.get(Content, content_id)
            if not content:
                raise ValueError(f"Content {content_id} not found")

            # Fetch accounts if not provided
            if not platform_accounts:
                stmt = select(PlatformAccount).where(PlatformAccount.is_active == True)
                result = await db.execute(stmt)
                platform_accounts = list(result.scalars().all())

            published_records = []

            for account in platform_accounts:
                try:
                    # Get the appropriate adapter
                    adapter = get_adapter(account.platform.value)

                    if auto_publish:
                        # Real publish via platform API
                        publish_result = await adapter.publish_content(
                            content={
                                "title": content.title,
                                "body": content.body,
                                "content_type": content.content_type.value,
                            },
                            account={
                                "account_id": account.account_id,
                                "access_token": account.access_token,
                            },
                        )
                        status = PublishStatus.PUBLISHED
                    else:
                        # Draft mode - record intent without publishing
                        publish_result = {
                            "platform": account.platform.value,
                            "post_id": None,
                            "status": "draft",
                        }
                        status = PublishStatus.DRAFT

                    # Record publication
                    published = PublishedContent(
                        id=uuid.uuid4(),
                        content_id=content_id,
                        account_id=account.id,
                        platform_post_id=publish_result.get("post_id"),
                        platform_url=publish_result.get("url"),
                        publish_status=status,
                        published_at=datetime.utcnow() if auto_publish else None,
                    )
                    db.add(published)
                    published_records.append(published)

                    self.log(
                        f"{'Published' if auto_publish else 'Prepared'} to "
                        f"{account.platform.value} ({account.account_name})"
                    )

                    await adapter.close()

                except Exception as e:
                    self.log(f"Failed to publish to {account.platform.value}: {e}")
                    # Create failed record
                    failed = PublishedContent(
                        id=uuid.uuid4(),
                        content_id=content_id,
                        account_id=account.id,
                        publish_status=PublishStatus.FAILED,
                        error_message=str(e),
                    )
                    db.add(failed)
                    published_records.append(failed)

            await db.commit()
            for p in published_records:
                await db.refresh(p)

            await self.complete_action(
                db,
                output={
                    "published_count": len(published_records),
                    "platforms": [p.account.platform.value if p.account else "unknown" for p in published_records],
                },
                reasoning=f"内容已{'发布' if auto_publish else '准备'}到 {len(published_records)} 个平台账号",
                llm_calls=llm_calls,
                tokens=tokens_used,
            )

            return published_records

        except Exception as e:
            await self.fail_action(db, str(e), llm_calls=llm_calls, tokens=tokens_used)
            raise

    async def analyze_and_reply_comments(
        self,
        db: AsyncSession,
        content_id: uuid.UUID | None = None,
        platform_post_id: str | None = None,
        workflow_run_id: uuid.UUID | None = None,
    ) -> list[Comment]:
        """Fetch comments, analyze sentiment, and generate replies."""
        workflow_run_id = workflow_run_id or uuid.uuid4()

        await self.start_action(
            db, workflow_run_id,
            action="评论分析与回复生成",
            input_data={
                "content_id": str(content_id) if content_id else None,
                "platform_post_id": platform_post_id,
            },
        )

        llm_calls = 0
        tokens_used = 0

        try:
            # For demo: generate simulated comments based on content
            if content_id:
                content = await db.get(Content, content_id)
                content_title = content.title if content else "Unknown"
            else:
                content_title = "Unknown"

            # Simulate fetching comments from platforms
            comments_data = [
                {"text": "讲的太棒了！正是我需要的，已三连！", "sentiment": "positive", "author": "用户_Alex"},
                {"text": "能不能出一期关于XXX的详细教程？", "sentiment": "question", "author": "学习小白2024"},
                {"text": "感觉内容有点浅，能不能讲深一点？", "sentiment": "suggestion", "author": "深度用户"},
                {"text": "已收藏，这种干货内容多出一点！", "sentiment": "positive", "author": "职场新人小王"},
                {"text": "这个观点不太同意，实际情况是...", "sentiment": "negative", "author": "业内老张"},
            ]

            processed_comments = []

            for cd in comments_data:
                # Generate AI reply
                reply_result = await self.think_json(
                    system_prompt=COMMENT_ANALYSIS_SYSTEM_PROMPT,
                    user_prompt=REPLY_GENERATION_PROMPT.format(
                        comment_text=cd["text"],
                        sentiment=cd["sentiment"],
                        author_name=cd["author"],
                        content_title=content_title,
                        account_tone="专业亲切",
                    ),
                )
                llm_calls += 1
                tokens_used += 500

                # Determine sentiment enum
                sentiment_map = {
                    "positive": CommentSentiment.POSITIVE,
                    "question": CommentSentiment.QUESTION,
                    "suggestion": CommentSentiment.SUGGESTION,
                    "negative": CommentSentiment.NEGATIVE,
                }
                sentiment = sentiment_map.get(cd["sentiment"], CommentSentiment.NEUTRAL)

                # Pick the first suggested reply
                suggested = reply_result.get("suggested_replies", [])
                reply_text = suggested[0]["text"] if suggested else "感谢您的评论！我们会继续努力产出优质内容~"

                # Create comment record
                comment = Comment(
                    id=uuid.uuid4(),
                    platform="simulated",
                    platform_comment_id=f"sim_{hash(cd['text']) % 10**8}",
                    platform_content_id=str(content_id) if content_id else "unknown",
                    author_name=cd["author"],
                    text=cd["text"],
                    sentiment=sentiment,
                    reply_text=reply_text,
                    reply_status=ReplyStatus.PUBLISHED,
                    is_replied=True,
                    replied_at=datetime.utcnow(),
                )
                db.add(comment)
                processed_comments.append(comment)

            await db.commit()
            for c in processed_comments:
                await db.refresh(c)

            await self.complete_action(
                db,
                output={
                    "comments_processed": len(processed_comments),
                    "replies_generated": len(processed_comments),
                },
                reasoning=f"处理了{len(processed_comments)}条评论并生成了AI回复",
                llm_calls=llm_calls,
                tokens=tokens_used,
            )

            return processed_comments

        except Exception as e:
            await self.fail_action(db, str(e), llm_calls=llm_calls, tokens=tokens_used)
            raise

    async def get_publishing_schedule(
        self,
        content_type: str,
        platforms: list[str],
        audience_profile: str = "",
    ) -> dict:
        """Get AI-recommended publishing schedule."""
        result = await self.think_json(
            system_prompt="你是一位内容发布策略专家，精通各平台流量算法和用户活跃规律。",
            user_prompt=SCHEDULING_PROMPT.format(
                content_type=content_type,
                platforms=", ".join(platforms),
                audience_profile=audience_profile,
                account_stats="历史发布数据暂缺",
            ),
        )
        return result
