"""Base agent class with shared logging and LLM access."""

import time
import uuid
from datetime import datetime
from typing import Any
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.utils.llm_adapter import llm
from app.models.workflow import AgentLog, AgentRole


class BaseAgent:
    """Base class for all content pipeline agents.

    Provides:
    - LLM access via self.llm (the singleton LLMAdapter)
    - Structured logging to AgentLog table
    - Token usage tracking
    - Error handling & reporting
    """

    def __init__(self, role: AgentRole):
        self.role = role
        self.llm = llm
        self._current_log: AgentLog | None = None

    async def start_action(
        self,
        db: AsyncSession,
        workflow_run_id: uuid.UUID,
        action: str,
        input_data: dict | None = None,
    ) -> AgentLog:
        """Create a new agent log entry for tracking this action."""
        log_entry = AgentLog(
            id=uuid.uuid4(),
            workflow_run_id=workflow_run_id,
            agent_role=self.role,
            action=action,
            status="running",
            input_snapshot=input_data or {},
            started_at=datetime.utcnow(),
        )
        db.add(log_entry)
        await db.commit()
        await db.refresh(log_entry)
        self._current_log = log_entry
        return log_entry

    async def complete_action(
        self,
        db: AsyncSession,
        output: dict | None = None,
        reasoning: str | None = None,
        llm_calls: int = 0,
        tokens: int = 0,
    ):
        """Mark the current action as completed."""
        if not self._current_log:
            return
        self._current_log.status = "completed"
        self._current_log.output_snapshot = output
        self._current_log.reasoning = reasoning
        self._current_log.llm_call_count = llm_calls
        self._current_log.tokens_used = tokens
        self._current_log.completed_at = datetime.utcnow()
        if self._current_log.started_at:
            delta = datetime.utcnow() - self._current_log.started_at
            self._current_log.duration_ms = int(delta.total_seconds() * 1000)
        await db.commit()

    async def fail_action(
        self, db: AsyncSession, error: str, llm_calls: int = 0, tokens: int = 0
    ):
        """Mark the current action as failed."""
        if not self._current_log:
            return
        self._current_log.status = "failed"
        self._current_log.error_message = error
        self._current_log.llm_call_count = llm_calls
        self._current_log.tokens_used = tokens
        self._current_log.completed_at = datetime.utcnow()
        if self._current_log.started_at:
            delta = datetime.utcnow() - self._current_log.started_at
            self._current_log.duration_ms = int(delta.total_seconds() * 1000)
        await db.commit()

    async def think(self, system_prompt: str, user_prompt: str, **kwargs) -> str:
        """Send a reasoning prompt to the LLM."""
        return await self.llm.chat(system_prompt, user_prompt, **kwargs)

    async def think_json(self, system_prompt: str, user_prompt: str, **kwargs) -> dict:
        """Send a reasoning prompt and get structured JSON back."""
        return await self.llm.chat_json(system_prompt, user_prompt, **kwargs)

    def log(self, msg: str, **extra):
        """Structured logging with agent context."""
        logger.info(f"[{self.role.value}] {msg}", extra=extra)
