"""
Agent Orchestrator — coordinates multi-agent collaboration for the full content pipeline.

Workflow:
1. Topic Research Agent: Analyze trends → Generate topic list
2. Content Generation Agent: Create content from topic → Adapt for platforms
3. Distribution Agent: Publish → Monitor comments → Reply
"""

import uuid
from datetime import datetime
from typing import Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.agents.base_agent import BaseAgent
from app.agents.topic_research_agent import TopicResearchAgent
from app.agents.content_generation_agent import ContentGenerationAgent
from app.agents.distribution_agent import DistributionAgent
from app.models.workflow import (
    WorkflowRun, AgentLog, WorkflowType, WorkflowStatus, AgentRole,
)
from app.models.topic import Topic, TopicStatus
from app.models.content import Content
from app.models.platform_account import PublishedContent, PublishStatus
from app.models.comment import Comment, ReplyStatus


class AgentOrchestrator(BaseAgent):
    """Orchestrates multi-agent collaboration for the full content pipeline."""

    def __init__(self):
        super().__init__(role=AgentRole.ORCHESTRATOR)
        self.topic_agent = TopicResearchAgent()
        self.content_agent = ContentGenerationAgent()
        self.distribution_agent = DistributionAgent()

    async def run_full_pipeline(
        self,
        db: AsyncSession,
        niche: str,
        keywords: list[str] | None = None,
        content_type: str = "short_video_script",
        platforms: list[str] | None = None,
        auto_publish: bool = False,
        tone: str = "专业易懂",
    ) -> dict[str, Any]:
        """Execute a complete end-to-end content pipeline.

        Steps:
        1. Topic Research → generates topic list
        2. Content Generation → creates content for the best topic
        3. Distribution → publishes & sets up interaction

        Returns:
            Dict with all pipeline outputs.
        """
        platforms = platforms or ["douyin", "bilibili", "xiaohongshu"]
        workflow_run_id = uuid.uuid4()

        # ── Create workflow run record ──
        workflow_run = WorkflowRun(
            id=workflow_run_id,
            workflow_type=WorkflowType.FULL_PIPELINE,
            status=WorkflowStatus.RUNNING,
            trigger="manual",
            input_data={
                "niche": niche,
                "keywords": keywords or [],
                "content_type": content_type,
                "platforms": platforms,
                "auto_publish": auto_publish,
                "tone": tone,
            },
            started_at=datetime.utcnow(),
        )
        db.add(workflow_run)
        await db.commit()

        await self.start_action(
            db, workflow_run_id,
            action="全流程内容生产管线",
            input_data=workflow_run.input_data,
        )

        pipeline_result = {
            "workflow_run_id": str(workflow_run_id),
            "niche": niche,
            "steps": [],
        }

        try:
            # ═══════════════════════════════════════════
            # Phase 1: Topic Research
            # ═══════════════════════════════════════════
            self.log(f"Phase 1: Researching topics for niche '{niche}'...")
            topics = await self.topic_agent.research_topics(
                db=db,
                niche=niche,
                keywords=keywords,
                platforms=platforms,
                workflow_run_id=workflow_run_id,
            )
            pipeline_result["steps"].append({
                "phase": "topic_research",
                "status": "completed",
                "topics_count": len(topics),
                "topic_ids": [str(t.id) for t in topics],
            })
            self.log(f"✓ Phase 1 complete: {len(topics)} topics generated")

            if not topics:
                raise ValueError("No topics generated — cannot continue pipeline")

            # ═══════════════════════════════════════════
            # Phase 2: Content Generation
            # ═══════════════════════════════════════════
            # Use the highest-scored topic
            best_topic = max(topics, key=lambda t: t.trend_score or 0)
            self.log(f"Phase 2: Generating {content_type} from topic '{best_topic.title}'...")

            content = await self.content_agent.generate_content(
                db=db,
                topic_id=best_topic.id,
                content_type=content_type,
                platform_targets=platforms,
                tone=tone,
                workflow_run_id=workflow_run_id,
            )
            pipeline_result["steps"].append({
                "phase": "content_generation",
                "status": "completed",
                "content_id": str(content.id),
                "content_title": content.title,
                "content_type": content_type,
            })
            self.log(f"✓ Phase 2 complete: content '{content.title}' generated")

            # Update workflow run with content reference
            workflow_run.content_id = content.id

            # ═══════════════════════════════════════════
            # Phase 3: Distribution & Interaction
            # ═══════════════════════════════════════════
            self.log(f"Phase 3: {'Auto-publishing' if auto_publish else 'Preparing'} content to platforms...")

            published = await self.distribution_agent.publish_content(
                db=db,
                content_id=content.id,
                auto_publish=auto_publish,
                workflow_run_id=workflow_run_id,
            )
            pipeline_result["steps"].append({
                "phase": "distribution",
                "status": "completed",
                "published_count": len(published),
                "auto_published": auto_publish,
            })

            # Simulate comment interaction
            self.log("Phase 3: Analyzing & replying to comments...")
            comments = await self.distribution_agent.analyze_and_reply_comments(
                db=db,
                content_id=content.id,
                workflow_run_id=workflow_run_id,
            )
            pipeline_result["steps"].append({
                "phase": "interaction",
                "status": "completed",
                "comments_processed": len(comments),
            })
            self.log(f"✓ Phase 3 complete: published to {len(published)} accounts, {len(comments)} comments handled")

            # ═══════════════════════════════════════════
            # Complete workflow
            # ═══════════════════════════════════════════
            workflow_run.status = WorkflowStatus.COMPLETED
            workflow_run.completed_at = datetime.utcnow()
            if workflow_run.started_at:
                delta = datetime.utcnow() - workflow_run.started_at
                workflow_run.duration_seconds = delta.total_seconds()
            workflow_run.output_summary = pipeline_result
            workflow_run.topic_id = best_topic.id
            await db.commit()

            await self.complete_action(
                db,
                output=pipeline_result,
                reasoning=f"全流程完成：{len(topics)}个选题 → 1篇{content_type} → {len(published)}个平台分发 → {len(comments)}条评论互动",
            )

            pipeline_result["status"] = "completed"
            pipeline_result["duration_seconds"] = workflow_run.duration_seconds
            return pipeline_result

        except Exception as e:
            workflow_run.status = WorkflowStatus.FAILED
            workflow_run.completed_at = datetime.utcnow()
            workflow_run.error_message = str(e)
            await db.commit()

            await self.fail_action(db, str(e))
            pipeline_result["status"] = "failed"
            pipeline_result["error"] = str(e)
            self.log(f"Pipeline failed: {e}")
            return pipeline_result

    async def run_topic_research_only(
        self,
        db: AsyncSession,
        niche: str,
        keywords: list[str] | None = None,
        platforms: list[str] | None = None,
        count: int = 5,
    ) -> dict[str, Any]:
        """Run only the topic research phase."""
        workflow_run_id = uuid.uuid4()

        workflow_run = WorkflowRun(
            id=workflow_run_id,
            workflow_type=WorkflowType.TOPIC_RESEARCH,
            status=WorkflowStatus.RUNNING,
            trigger="manual",
            input_data={"niche": niche, "keywords": keywords, "count": count},
            started_at=datetime.utcnow(),
        )
        db.add(workflow_run)
        await db.commit()

        try:
            topics = await self.topic_agent.research_topics(
                db=db, niche=niche, keywords=keywords,
                platforms=platforms, count=count,
                workflow_run_id=workflow_run_id,
            )

            workflow_run.status = WorkflowStatus.COMPLETED
            workflow_run.completed_at = datetime.utcnow()
            workflow_run.output_summary = {
                "topics_count": len(topics),
                "topic_ids": [str(t.id) for t in topics],
            }
            await db.commit()

            return {
                "workflow_run_id": str(workflow_run_id),
                "status": "completed",
                "topics": [
                    {
                        "id": str(t.id),
                        "title": t.title,
                        "trend_score": t.trend_score,
                        "competition_level": t.competition_level,
                    }
                    for t in topics
                ],
            }
        except Exception as e:
            workflow_run.status = WorkflowStatus.FAILED
            workflow_run.error_message = str(e)
            await db.commit()
            return {"workflow_run_id": str(workflow_run_id), "status": "failed", "error": str(e)}

    async def run_content_generation_only(
        self,
        db: AsyncSession,
        topic_id: uuid.UUID,
        content_type: str = "short_video_script",
        platforms: list[str] | None = None,
        tone: str = "专业易懂",
    ) -> dict[str, Any]:
        """Run only the content generation phase from an existing topic."""
        workflow_run_id = uuid.uuid4()

        workflow_run = WorkflowRun(
            id=workflow_run_id,
            workflow_type=WorkflowType.CONTENT_GENERATION,
            status=WorkflowStatus.RUNNING,
            trigger="manual",
            input_data={
                "topic_id": str(topic_id),
                "content_type": content_type,
                "tone": tone,
            },
            started_at=datetime.utcnow(),
        )
        db.add(workflow_run)
        await db.commit()

        try:
            content = await self.content_agent.generate_content(
                db=db,
                topic_id=topic_id,
                content_type=content_type,
                platform_targets=platforms,
                tone=tone,
                workflow_run_id=workflow_run_id,
            )

            workflow_run.status = WorkflowStatus.COMPLETED
            workflow_run.content_id = content.id
            workflow_run.completed_at = datetime.utcnow()
            workflow_run.output_summary = {
                "content_id": str(content.id),
                "title": content.title,
                "content_type": content_type,
            }
            await db.commit()

            return {
                "workflow_run_id": str(workflow_run_id),
                "status": "completed",
                "content": {
                    "id": str(content.id),
                    "title": content.title,
                    "body": content.body,
                    "hashtags": content.hashtags,
                },
            }
        except Exception as e:
            workflow_run.status = WorkflowStatus.FAILED
            workflow_run.error_message = str(e)
            await db.commit()
            return {"workflow_run_id": str(workflow_run_id), "status": "failed", "error": str(e)}

    @staticmethod
    async def get_workflow_status(
        db: AsyncSession, workflow_run_id: uuid.UUID
    ) -> dict[str, Any] | None:
        """Get the status and details of a workflow run."""
        workflow_run = await db.get(WorkflowRun, workflow_run_id)
        if not workflow_run:
            return None

        # Fetch agent logs
        stmt = (
            select(AgentLog)
            .where(AgentLog.workflow_run_id == workflow_run_id)
            .order_by(AgentLog.started_at)
        )
        result = await db.execute(stmt)
        logs = result.scalars().all()

        return {
            "id": str(workflow_run.id),
            "workflow_type": workflow_run.workflow_type.value,
            "status": workflow_run.status.value,
            "trigger": workflow_run.trigger,
            "started_at": workflow_run.started_at.isoformat() if workflow_run.started_at else None,
            "completed_at": workflow_run.completed_at.isoformat() if workflow_run.completed_at else None,
            "duration_seconds": workflow_run.duration_seconds,
            "error_message": workflow_run.error_message,
            "output_summary": workflow_run.output_summary,
            "agent_logs": [
                {
                    "role": log.agent_role.value,
                    "action": log.action,
                    "status": log.status,
                    "duration_ms": log.duration_ms,
                    "llm_calls": log.llm_call_count,
                    "error": log.error_message,
                }
                for log in logs
            ],
        }

    @staticmethod
    async def get_dashboard_stats(db: AsyncSession) -> dict[str, Any]:
        """Get aggregate statistics for the dashboard."""
        # Count topics
        topic_count = await db.scalar(select(func.count(Topic.id)))

        # Count contents
        content_count = await db.scalar(select(func.count(Content.id)))

        # Count published
        published_count = await db.scalar(
            select(func.count(PublishedContent.id)).where(
                PublishedContent.publish_status == PublishStatus.PUBLISHED
            )
        )

        # Count comments pending
        pending_replies = await db.scalar(
            select(func.count(Comment.id)).where(Comment.reply_status == ReplyStatus.PENDING)
        )

        # Recent workflow runs
        stmt = (
            select(WorkflowRun)
            .order_by(WorkflowRun.created_at.desc())
            .limit(5)
        )
        result = await db.execute(stmt)
        recent_runs = result.scalars().all()

        return {
            "total_topics": topic_count or 0,
            "total_contents": content_count or 0,
            "total_published": published_count or 0,
            "pending_replies": pending_replies or 0,
            "recent_runs": [
                {
                    "id": str(r.id),
                    "type": r.workflow_type.value,
                    "status": r.status.value,
                    "duration": r.duration_seconds,
                    "created_at": r.created_at.isoformat(),
                }
                for r in recent_runs
            ],
        }
