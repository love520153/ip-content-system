"""
IP Content Auto-Production System — FastAPI Main Application

全栈内容创作自动化系统：
- 选题调研 Agent
- 内容生成 Agent
- 分发与互动 Agent
"""

import uuid
from contextlib import asynccontextmanager
from loguru import logger

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.database import init_db, async_session_factory
from app.api.topics import router as topics_router
from app.api.contents import router as contents_router
from app.api.platforms import router as platforms_router
from app.api.workflow import router as workflow_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: initialize database on startup."""
    logger.info("🚀 IP Content System starting up...")
    logger.info(f"   LLM Provider: {settings.llm_provider}/{settings.llm_model}")
    try:
        await init_db()
        logger.info("   Database tables created/verified")
    except Exception as e:
        logger.warning(f"   Database init (may retry on first request): {e}")
    yield
    logger.info("Shutting down IP Content System...")


app = FastAPI(
    title="IP Content Auto-Production System",
    description="""内容创作全流程自动化系统
    \n\n## 三大核心 Agent
    \n1. **选题调研 Agent** — 热点趋势抓取、用户偏好分析、差异化选题生成
    \n2. **内容生成 Agent** — 多平台适配脚本/图文/直播话术生成
    \n3. **分发与互动 Agent** — 自动发布、评论分析、拟真回复
    """,
    version="1.0.0",
    lifespan=lifespan,
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(topics_router)
app.include_router(contents_router)
app.include_router(platforms_router)
app.include_router(workflow_router)


@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "ok",
        "version": "1.0.0",
        "llm_provider": settings.llm_provider,
        "llm_model": settings.llm_model,
    }


@app.get("/api/config")
async def get_config():
    """Get public configuration info (no secrets)."""
    return {
        "llm_provider": settings.llm_provider,
        "llm_model": settings.llm_model,
        "has_fallback": bool(settings.llm_fallback_provider),
        "platforms_configured": [
            p for p in ["douyin", "bilibili", "xiaohongshu", "wechat"]
            if getattr(settings, f"{p}_app_id", None)
        ],
        "debug": settings.debug,
    }


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler."""
    logger.error(f"Unhandled exception: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": str(exc), "type": type(exc).__name__},
    )


# ── Entry point ─────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
    )
