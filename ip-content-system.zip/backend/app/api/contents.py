"""Content management API endpoints."""

import uuid
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.database import get_db
from app.models.content import Content, ContentVariant, ContentStatus
from app.schemas.content import (
    ContentCreate, ContentResponse, ContentVariantResponse,
    ContentGenerationRequest,
)
from app.agents.orchestrator import AgentOrchestrator

router = APIRouter(prefix="/api/contents", tags=["内容管理"])


@router.get("")
async def list_contents(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    topic_id: uuid.UUID | None = None,
    content_type: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    """List all content with optional filtering."""
    query = select(Content)

    if topic_id:
        query = query.where(Content.topic_id == topic_id)
    if content_type:
        query = query.where(Content.content_type == content_type)

    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query) or 0

    query = query.order_by(Content.created_at.desc())
    query = query.offset((page - 1) * page_size).limit(page_size)
    result = await db.execute(query)
    contents = result.scalars().all()

    return {
        "items": [ContentResponse.model_validate(c) for c in contents],
        "total": total,
    }


@router.get("/{content_id}", response_model=ContentResponse)
async def get_content(content_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    """Get a single content item by ID."""
    content = await db.get(Content, content_id)
    if not content:
        raise HTTPException(status_code=404, detail="Content not found")

    # Fetch variants
    stmt = select(ContentVariant).where(ContentVariant.content_id == content_id)
    result = await db.execute(stmt)
    variants = result.scalars().all()

    content_resp = ContentResponse.model_validate(content)
    content_resp.variants = [ContentVariantResponse.model_validate(v) for v in variants]
    return content_resp


@router.post("/generate", status_code=201)
async def generate_content(
    request: ContentGenerationRequest,
    db: AsyncSession = Depends(get_db),
):
    """Run content generation agent from a topic."""
    orchestrator = AgentOrchestrator()
    result = await orchestrator.run_content_generation_only(
        db=db,
        topic_id=request.topic_id,
        content_type=request.content_type,
        platforms=request.platform_targets,
        tone=request.tone,
    )
    return result


@router.post("", response_model=ContentResponse, status_code=201)
async def create_content(data: ContentCreate, db: AsyncSession = Depends(get_db)):
    """Manually create content."""
    content = Content(
        id=uuid.uuid4(),
        topic_id=data.topic_id,
        title=data.title,
        content_type=data.content_type,
        body=data.body,
        platform_target=data.platform_target,
        hashtags=data.hashtags,
        seo_keywords=data.seo_keywords,
        status=ContentStatus.DRAFT,
    )
    db.add(content)
    await db.commit()
    await db.refresh(content)
    return ContentResponse.model_validate(content)


@router.delete("/{content_id}")
async def delete_content(content_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    """Delete content."""
    content = await db.get(Content, content_id)
    if not content:
        raise HTTPException(status_code=404, detail="Content not found")
    await db.delete(content)
    await db.commit()
    return {"status": "deleted"}
