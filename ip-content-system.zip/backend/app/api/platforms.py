"""Platform & distribution API endpoints."""

import uuid
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.database import get_db
from app.models.platform_account import PlatformAccount, PublishedContent
from app.models.comment import Comment, ReplyTemplate, CommentSentiment
from app.agents.distribution_agent import DistributionAgent

router = APIRouter(prefix="/api/platforms", tags=["平台管理"])


# ── Platform Accounts ────────────────────────────────────────────

@router.get("/accounts")
async def list_accounts(db: AsyncSession = Depends(get_db)):
    """List all connected platform accounts."""
    stmt = select(PlatformAccount).order_by(PlatformAccount.platform)
    result = await db.execute(stmt)
    accounts = result.scalars().all()
    return {
        "items": [
            {
                "id": str(a.id),
                "platform": a.platform.value,
                "account_name": a.account_name,
                "followers_count": a.followers_count,
                "is_active": a.is_active,
            }
            for a in accounts
        ],
        "total": len(accounts),
    }


# ── Publishing ───────────────────────────────────────────────────

@router.post("/publish/{content_id}")
async def publish_content(
    content_id: uuid.UUID,
    auto_publish: bool = Query(False),
    db: AsyncSession = Depends(get_db),
):
    """Publish content to all active platform accounts."""
    agent = DistributionAgent()
    result = await agent.publish_content(
        db=db,
        content_id=content_id,
        auto_publish=auto_publish,
    )
    return {
        "published": [
            {
                "id": str(p.id),
                "platform": p.account.platform.value if p.account else "unknown",
                "status": p.publish_status.value,
                "url": p.platform_url,
            }
            for p in result
        ],
    }


# ── Comments & Interaction ──────────────────────────────────────

@router.get("/comments")
async def list_comments(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    platform: str | None = None,
    sentiment: str | None = None,
    is_priority: bool | None = None,
    db: AsyncSession = Depends(get_db),
):
    """List comments with filtering."""
    query = select(Comment)

    if platform:
        query = query.where(Comment.platform == platform)
    if sentiment:
        query = query.where(Comment.sentiment == CommentSentiment(sentiment))
    if is_priority is not None:
        query = query.where(Comment.is_priority == is_priority)

    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query) or 0

    query = query.order_by(Comment.created_at.desc())
    query = query.offset((page - 1) * page_size).limit(page_size)
    result = await db.execute(query)
    comments = result.scalars().all()

    return {
        "items": [
            {
                "id": str(c.id),
                "platform": c.platform,
                "author_name": c.author_name,
                "text": c.text,
                "sentiment": c.sentiment.value,
                "is_replied": c.is_replied,
                "reply_text": c.reply_text,
                "is_priority": c.is_priority,
                "created_at": c.created_at.isoformat(),
            }
            for c in comments
        ],
        "total": total,
    }


@router.post("/comments/analyze/{content_id}")
async def analyze_comments(
    content_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
):
    """Analyze comments and generate replies for a published content."""
    agent = DistributionAgent()
    comments = await agent.analyze_and_reply_comments(
        db=db,
        content_id=content_id,
    )
    return {
        "processed": len(comments),
        "comments": [
            {
                "id": str(c.id),
                "author": c.author_name,
                "text": c.text,
                "reply": c.reply_text,
            }
            for c in comments
        ],
    }


@router.get("/reply-templates")
async def list_reply_templates(
    sentiment: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    """List reply templates."""
    query = select(ReplyTemplate).where(ReplyTemplate.is_active == True)
    if sentiment:
        query = query.where(ReplyTemplate.sentiment_type == CommentSentiment(sentiment))
    result = await db.execute(query)
    templates = result.scalars().all()
    return {
        "items": [
            {
                "id": str(t.id),
                "name": t.name,
                "content": t.content,
                "tone": t.tone,
                "sentiment_type": t.sentiment_type.value,
                "use_count": t.use_count,
            }
            for t in templates
        ],
    }


# ── Published Content History ────────────────────────────────────

@router.get("/published")
async def list_published(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    """List all published content records."""
    stmt = (
        select(PublishedContent)
        .order_by(PublishedContent.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )
    result = await db.execute(stmt)
    items = result.scalars().all()

    return {
        "items": [
            {
                "id": str(p.id),
                "content_id": str(p.content_id),
                "platform": p.account.platform.value if p.account else "unknown",
                "status": p.publish_status.value,
                "url": p.platform_url,
                "views": p.views_count,
                "likes": p.likes_count,
                "comments": p.comments_count,
                "published_at": p.published_at.isoformat() if p.published_at else None,
            }
            for p in items
        ],
        "total": len(items),
    }


@router.get("/schedule")
async def get_publishing_schedule(
    content_type: str = Query("short_video_script"),
    platforms: str = Query("douyin,bilibili,xiaohongshu"),
):
    """Get AI-recommended publishing schedule."""
    agent = DistributionAgent()
    schedule = await agent.get_publishing_schedule(
        content_type=content_type,
        platforms=platforms.split(","),
    )
    return schedule
