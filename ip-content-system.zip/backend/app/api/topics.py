"""Topic research API endpoints."""

import uuid
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.database import get_db
from app.models.topic import Topic, TopicStatus
from app.models.workflow import WorkflowRun, WorkflowType, WorkflowStatus
from app.schemas.topic import (
    TopicCreate, TopicResponse, TopicList, TopicAnalysisRequest, TopicAnalysisResponse,
)
from app.agents.orchestrator import AgentOrchestrator

router = APIRouter(prefix="/api/topics", tags=["选题管理"])


@router.get("", response_model=TopicList)
async def list_topics(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: str | None = None,
    niche: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    """List all topics with optional filtering."""
    query = select(Topic)

    if status:
        query = query.where(Topic.status == TopicStatus(status))
    if niche:
        query = query.where(Topic.niche.ilike(f"%{niche}%"))

    # Get total count
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query) or 0

    # Paginated results
    query = query.order_by(Topic.created_at.desc())
    query = query.offset((page - 1) * page_size).limit(page_size)
    result = await db.execute(query)
    topics = result.scalars().all()

    return TopicList(
        items=[TopicResponse.model_validate(t) for t in topics],
        total=total,
    )


@router.get("/{topic_id}", response_model=TopicResponse)
async def get_topic(topic_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    """Get a single topic by ID."""
    topic = await db.get(Topic, topic_id)
    if not topic:
        raise HTTPException(status_code=404, detail="Topic not found")
    return TopicResponse.model_validate(topic)


@router.post("", response_model=TopicResponse, status_code=201)
async def create_topic(data: TopicCreate, db: AsyncSession = Depends(get_db)):
    """Manually create a new topic."""
    topic = Topic(
        id=uuid.uuid4(),
        title=data.title,
        description=data.description,
        keywords=data.keywords,
        category=data.category,
        niche=data.niche or data.category or "general",
        source=data.source,
        source_url=data.source_url,
        status=TopicStatus.READY,
    )
    db.add(topic)
    await db.commit()
    await db.refresh(topic)
    return TopicResponse.model_validate(topic)


@router.post("/analyze", response_model=TopicAnalysisResponse)
async def analyze_topics(
    request: TopicAnalysisRequest,
    db: AsyncSession = Depends(get_db),
):
    """Run topic research agent to analyze and generate topics."""
    orchestrator = AgentOrchestrator()
    result = await orchestrator.run_topic_research_only(
        db=db,
        niche=request.niche,
        keywords=request.keywords,
        platforms=request.platforms,
        count=request.count,
    )

    # Fetch the created topics
    topic_ids = [t.get("id") for t in result.get("topics", [])]
    topics = []
    for tid in topic_ids:
        topic = await db.get(Topic, uuid.UUID(tid))
        if topic:
            topics.append(TopicResponse.model_validate(topic))

    return TopicAnalysisResponse(
        topics=topics,
        workflow_run_id=uuid.UUID(result["workflow_run_id"]) if result.get("workflow_run_id") else None,
    )


@router.patch("/{topic_id}/status")
async def update_topic_status(
    topic_id: uuid.UUID,
    status: str = Query(...),
    db: AsyncSession = Depends(get_db),
):
    """Update topic status."""
    topic = await db.get(Topic, topic_id)
    if not topic:
        raise HTTPException(status_code=404, detail="Topic not found")
    topic.status = TopicStatus(status)
    await db.commit()
    return {"status": "updated"}


@router.delete("/{topic_id}")
async def delete_topic(topic_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    """Delete a topic."""
    topic = await db.get(Topic, topic_id)
    if not topic:
        raise HTTPException(status_code=404, detail="Topic not found")
    await db.delete(topic)
    await db.commit()
    return {"status": "deleted"}
