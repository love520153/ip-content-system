"""Workflow orchestration API endpoints."""

import uuid
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.database import get_db
from app.models.workflow import WorkflowRun, WorkflowStatus
from app.schemas.workflow import (
    WorkflowCreateRequest, WorkflowRunResponse, WorkflowFullPipelineRequest,
    WorkflowRunListResponse, DashboardStats,
)
from app.agents.orchestrator import AgentOrchestrator

router = APIRouter(prefix="/api/workflows", tags=["工作流"])


@router.get("", response_model=WorkflowRunListResponse)
async def list_workflow_runs(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    """List workflow run history."""
    stmt = (
        select(WorkflowRun)
        .order_by(WorkflowRun.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )
    count_stmt = select(func.count()).select_from(select(WorkflowRun).subquery())
    total = await db.scalar(count_stmt) or 0

    result = await db.execute(stmt)
    runs = result.scalars().all()

    return WorkflowRunListResponse(
        items=[WorkflowRunResponse.model_validate(r) for r in runs],
        total=total,
    )


@router.get("/{workflow_id}")
async def get_workflow_status(
    workflow_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
):
    """Get detailed status of a workflow run."""
    result = await AgentOrchestrator.get_workflow_status(db, workflow_id)
    if not result:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Workflow not found")
    return result


@router.post("/full-pipeline")
async def run_full_pipeline(
    request: WorkflowFullPipelineRequest,
    db: AsyncSession = Depends(get_db),
):
    """Execute the complete content creation pipeline."""
    orchestrator = AgentOrchestrator()
    result = await orchestrator.run_full_pipeline(
        db=db,
        niche=request.niche,
        keywords=request.keywords,
        content_type=request.content_type,
        platforms=request.platforms,
        auto_publish=request.auto_publish,
        tone=request.tone,
    )
    return result


@router.post("/topic-research")
async def run_topic_research(
    request: WorkflowFullPipelineRequest,
    db: AsyncSession = Depends(get_db),
):
    """Run only the topic research phase."""
    orchestrator = AgentOrchestrator()
    result = await orchestrator.run_topic_research_only(
        db=db,
        niche=request.niche,
        keywords=request.keywords,
        platforms=request.platforms,
    )
    return result


@router.get("/stats/dashboard", response_model=DashboardStats)
async def get_dashboard_stats(
    db: AsyncSession = Depends(get_db),
):
    """Get dashboard statistics."""
    stats = await AgentOrchestrator.get_dashboard_stats(db)

    # Get recent runs as WorkflowRunResponse objects
    recent_runs = []
    for r in stats.get("recent_runs", []):
        wr = await db.get(WorkflowRun, uuid.UUID(r["id"]))
        if wr:
            recent_runs.append(WorkflowRunResponse.model_validate(wr))

    return DashboardStats(
        total_topics=stats["total_topics"],
        total_contents=stats["total_contents"],
        total_published=stats["total_published"],
        total_comments=stats.get("total_comments", 0),
        pending_replies=stats["pending_replies"],
        active_accounts=stats.get("active_accounts", 0),
        avg_quality_score=stats.get("avg_quality_score", 0.0),
        recent_runs=recent_runs,
    )
