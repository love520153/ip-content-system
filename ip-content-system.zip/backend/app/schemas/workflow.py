"""Pydantic schemas for workflow and agent execution."""

import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class WorkflowCreateRequest(BaseModel):
    workflow_type: str = Field(..., description="workflow type")
    trigger: str = "manual"
    input_data: dict = Field(default_factory=dict)


class WorkflowFullPipelineRequest(BaseModel):
    """Full end-to-end pipeline: topic research → content generation → distribution."""
    niche: str = Field(..., description="内容赛道")
    keywords: list[str] = Field(default_factory=list)
    content_type: str = Field(default="short_video_script")
    platforms: list[str] = Field(
        default_factory=lambda: ["douyin", "bilibili", "xiaohongshu"],
    )
    auto_publish: bool = Field(default=False, description="是否自动发布到平台")
    tone: str = Field(default="专业易懂")


class WorkflowRunResponse(BaseModel):
    id: uuid.UUID
    workflow_type: str
    status: str
    trigger: str
    started_at: datetime | None
    completed_at: datetime | None
    duration_seconds: float | None
    error_message: str | None
    output_summary: dict | None
    topic_id: str | None
    content_id: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class AgentLogResponse(BaseModel):
    id: uuid.UUID
    workflow_run_id: uuid.UUID
    agent_role: str
    action: str
    status: str
    llm_call_count: int
    tokens_used: int
    reasoning: str | None
    error_message: str | None
    started_at: datetime
    completed_at: datetime | None
    duration_ms: int | None

    model_config = {"from_attributes": True}


class WorkflowRunListResponse(BaseModel):
    items: list[WorkflowRunResponse]
    total: int


class DashboardStats(BaseModel):
    total_topics: int
    total_contents: int
    total_published: int
    total_comments: int
    pending_replies: int
    active_accounts: int
    avg_quality_score: float
    recent_runs: list[WorkflowRunResponse]
