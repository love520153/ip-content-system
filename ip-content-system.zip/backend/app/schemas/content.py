"""Pydantic schemas for content-related API requests/responses."""

import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class ContentCreate(BaseModel):
    topic_id: uuid.UUID
    title: str
    content_type: str = "short_video_script"
    platform_target: str = "all"
    body: str | None = None
    hashtags: list[str] = Field(default_factory=list)
    seo_keywords: list[str] = Field(default_factory=list)


class ContentResponse(BaseModel):
    id: uuid.UUID
    topic_id: uuid.UUID
    title: str
    content_type: str
    body: str | None
    summary: str | None
    platform_target: str
    hashtags: list[str]
    seo_keywords: list[str]
    cover_image_prompt: str | None
    suggested_music: str | None
    status: str
    quality_score: int | None
    created_at: datetime
    updated_at: datetime
    variants: list["ContentVariantResponse"] = []

    model_config = {"from_attributes": True}


class ContentVariantResponse(BaseModel):
    id: uuid.UUID
    platform: str
    adapted_body: str | None
    adapted_title: str | None
    hashtags: list[str]
    notes: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class ContentGenerationRequest(BaseModel):
    topic_id: uuid.UUID = Field(..., description="选题ID")
    content_type: str = Field(
        default="short_video_script",
        description="内容类型: short_video_script / image_text_post / livestream_script / article",
    )
    platform_targets: list[str] = Field(
        default_factory=lambda: ["douyin", "bilibili", "xiaohongshu"],
        description="目标发布平台列表",
    )
    tone: str = Field(default="专业易懂", description="内容风格：专业易懂 / 轻松有趣 / 深度干货")
    additional_instructions: str | None = None
