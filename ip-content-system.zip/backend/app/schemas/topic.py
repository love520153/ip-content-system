"""Pydantic schemas for topic-related API requests/responses."""

import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class TopicCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=500, description="选题标题")
    description: str | None = None
    keywords: list[str] = Field(default_factory=list)
    category: str | None = None
    niche: str | None = None
    source: str = "manual"
    source_url: str | None = None


class TopicResponse(BaseModel):
    id: uuid.UUID
    title: str
    description: str | None
    keywords: list[str]
    category: str | None
    niche: str | None
    trend_score: float | None
    competition_level: str | None
    estimated_views: int | None
    source: str
    differentiation_points: list[str]
    target_audience: str | None
    content_angles: list[str]
    status: str
    platform_suitability: dict | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class TopicList(BaseModel):
    items: list[TopicResponse]
    total: int


class TopicAnalysisRequest(BaseModel):
    niche: str = Field(..., description="内容赛道/领域，如'职场干货'")
    keywords: list[str] = Field(default_factory=list, description="核心关键词")
    count: int = Field(default=5, ge=1, le=20, description="生成选题数量")
    platforms: list[str] = Field(
        default_factory=lambda: ["douyin", "bilibili", "xiaohongshu"],
        description="目标平台",
    )


class TopicAnalysisResponse(BaseModel):
    topics: list[TopicResponse]
    workflow_run_id: uuid.UUID | None = None
