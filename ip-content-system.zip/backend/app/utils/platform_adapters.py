"""
Platform adapters for content publishing and comment management.

Each platform adapter implements a common interface for:
- Publishing content (video, image-text, article)
- Fetching comments
- Replying to comments
- Getting account stats

In production, these would use the platform's official API.
For development, they use HTTPX with mock-able responses.
"""

import abc
from typing import Any
from loguru import logger
import httpx

from app.config import settings


class PlatformAdapter(abc.ABC):
    """Abstract base class for all platform adapters."""

    def __init__(self):
        self.client = httpx.AsyncClient(timeout=30.0)

    @abc.abstractmethod
    async def publish_content(self, content: dict, account: dict) -> dict:
        """Publish content to the platform. Returns platform post info."""
        ...

    @abc.abstractmethod
    async def fetch_comments(
        self, post_id: str, page: int = 1, page_size: int = 20
    ) -> list[dict]:
        """Fetch comments for a given post."""
        ...

    @abc.abstractmethod
    async def reply_to_comment(
        self, comment_id: str, reply_text: str
    ) -> dict:
        """Reply to a specific comment."""
        ...

    @abc.abstractmethod
    async def get_account_stats(self) -> dict:
        """Get account statistics (followers, engagement, etc.)."""
        ...

    async def close(self):
        await self.client.aclose()


class DouyinAdapter(PlatformAdapter):
    """ByteDance Douyin (TikTok China) adapter."""

    BASE_URL = "https://open.douyin.com"

    async def publish_content(self, content: dict, account: dict) -> dict:
        logger.info(f"[Douyin] Publishing: {content.get('title', '')[:30]}")
        # In production: POST /video/create/ with OAuth token
        # Mock implementation:
        return {
            "platform": "douyin",
            "post_id": f"dy_{account.get('account_id')}_{hash(str(content)) % 10**8}",
            "status": "published",
            "url": f"https://www.douyin.com/video/mock_{hash(str(content)) % 10**8}",
        }

    async def fetch_comments(
        self, post_id: str, page: int = 1, page_size: int = 20
    ) -> list[dict]:
        logger.info(f"[Douyin] Fetching comments for {post_id}")
        return []

    async def reply_to_comment(self, comment_id: str, reply_text: str) -> dict:
        logger.info(f"[Douyin] Replying to {comment_id}")
        return {"platform": "douyin", "comment_id": comment_id, "status": "replied"}

    async def get_account_stats(self) -> dict:
        return {
            "platform": "douyin",
            "followers": 0,
            "total_likes": 0,
            "total_views": 0,
        }


class BilibiliAdapter(PlatformAdapter):
    """Bilibili adapter."""

    BASE_URL = "https://api.bilibili.com"

    async def publish_content(self, content: dict, account: dict) -> dict:
        logger.info(f"[Bilibili] Publishing: {content.get('title', '')[:30]}")
        return {
            "platform": "bilibili",
            "post_id": f"bv_{hash(str(content)) % 10**8}",
            "status": "published",
            "url": f"https://www.bilibili.com/video/BV{mock_hash(str(content))}",
        }

    async def fetch_comments(
        self, post_id: str, page: int = 1, page_size: int = 20
    ) -> list[dict]:
        logger.info(f"[Bilibili] Fetching comments for {post_id}")
        return []

    async def reply_to_comment(self, comment_id: str, reply_text: str) -> dict:
        logger.info(f"[Bilibili] Replying to {comment_id}")
        return {"platform": "bilibili", "comment_id": comment_id, "status": "replied"}

    async def get_account_stats(self) -> dict:
        return {
            "platform": "bilibili",
            "followers": 0,
            "total_views": 0,
        }


class XiaohongshuAdapter(PlatformAdapter):
    """Xiaohongshu (RED) adapter."""

    BASE_URL = "https://open.xiaohongshu.com"

    async def publish_content(self, content: dict, account: dict) -> dict:
        logger.info(f"[Xiaohongshu] Publishing: {content.get('title', '')[:30]}")
        return {
            "platform": "xiaohongshu",
            "post_id": f"note_{hash(str(content)) % 10**8}",
            "status": "published",
            "url": f"https://www.xiaohongshu.com/explore/mock_{hash(str(content)) % 10**8}",
        }

    async def fetch_comments(
        self, post_id: str, page: int = 1, page_size: int = 20
    ) -> list[dict]:
        logger.info(f"[Xiaohongshu] Fetching comments for {post_id}")
        return []

    async def reply_to_comment(self, comment_id: str, reply_text: str) -> dict:
        logger.info(f"[Xiaohongshu] Replying to {comment_id}")
        return {"platform": "xiaohongshu", "comment_id": comment_id, "status": "replied"}

    async def get_account_stats(self) -> dict:
        return {"platform": "xiaohongshu", "followers": 0, "total_notes": 0}


class WechatAdapter(PlatformAdapter):
    """WeChat Official Account adapter."""

    BASE_URL = "https://api.weixin.qq.com"

    async def publish_content(self, content: dict, account: dict) -> dict:
        logger.info(f"[WeChat] Publishing: {content.get('title', '')[:30]}")
        return {
            "platform": "wechat",
            "post_id": f"wx_{hash(str(content)) % 10**8}",
            "status": "published",
        }

    async def fetch_comments(
        self, post_id: str, page: int = 1, page_size: int = 20
    ) -> list[dict]:
        return []

    async def reply_to_comment(self, comment_id: str, reply_text: str) -> dict:
        return {"platform": "wechat", "comment_id": comment_id, "status": "replied"}

    async def get_account_stats(self) -> dict:
        return {"platform": "wechat", "followers": 0}


def mock_hash(content: str) -> str:
    """Simple mock hash for generating fake IDs."""
    import hashlib
    return hashlib.md5(content.encode()).hexdigest()[:8]


def get_adapter(platform: str) -> PlatformAdapter:
    """Factory: get the appropriate platform adapter."""
    adapters = {
        "douyin": DouyinAdapter,
        "bilibili": BilibiliAdapter,
        "xiaohongshu": XiaohongshuAdapter,
        "wechat": WechatAdapter,
    }
    adapter_cls = adapters.get(platform)
    if not adapter_cls:
        raise ValueError(f"Unsupported platform: {platform}")
    return adapter_cls()
