"""
Multi-model LLM adapter using LiteLLM.

Supports OpenAI, Anthropic Claude, Google Gemini, DeepSeek, Moonshot,
and 100+ other models through a unified interface with automatic fallback.
"""

import json
from typing import Any
from loguru import logger

import litellm
from litellm import acompletion

from app.config import settings

# Disable LiteLLM telemetry
litellm.telemetry = False
litellm.drop_params = True


class LLMAdapter:
    """Unified LLM interface with fallback support."""

    def __init__(self):
        self.provider = settings.llm_provider
        self.model = settings.llm_model
        self.api_key = settings.llm_api_key
        self.api_base = settings.llm_api_base
        self.max_tokens = settings.llm_max_tokens
        self.temperature = settings.llm_temperature

        # Fallback config
        self.fallback_provider = settings.llm_fallback_provider
        self.fallback_model = settings.llm_fallback_model
        self.fallback_api_key = settings.llm_fallback_api_key

    def _build_model_name(self, provider: str, model: str) -> str:
        """Build the LiteLLM model string (e.g. 'openai/gpt-4o', 'anthropic/claude-sonnet-4-20250514')."""
        if "/" in model:
            return model
        return f"{provider}/{model}"

    def _build_kwargs(self, model_name: str, api_key: str | None = None) -> dict:
        """Build LiteLLM completion kwargs."""
        kwargs: dict[str, Any] = {
            "model": model_name,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        if api_key:
            kwargs["api_key"] = api_key
        if self.api_base and self.provider in model_name:
            kwargs["api_base"] = self.api_base
        return kwargs

    async def chat(
        self,
        system_prompt: str,
        user_prompt: str,
        output_json: bool = False,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """Send a chat completion request with automatic fallback support.

        Args:
            system_prompt: System-level instruction.
            user_prompt: User message content.
            output_json: If True, requests structured JSON output.
            temperature: Override default temperature.
            max_tokens: Override default max tokens.

        Returns:
            The model's response text.
        """
        primary_model = self._build_model_name(self.provider, self.model)
        kwargs = self._build_kwargs(primary_model, self.api_key)

        if temperature is not None:
            kwargs["temperature"] = temperature
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        kwargs["messages"] = messages

        if output_json:
            kwargs["response_format"] = {"type": "json_object"}

        # Try primary model first
        try:
            logger.info(f"LLM call: {primary_model}")
            response = await acompletion(**kwargs)
            return response.choices[0].message.content or ""
        except Exception as e:
            logger.warning(f"Primary model {primary_model} failed: {e}")
            if not self.fallback_provider or not self.fallback_model:
                raise

            # Try fallback model
            fallback_model = self._build_model_name(
                self.fallback_provider, self.fallback_model
            )
            fallback_kwargs = self._build_kwargs(
                fallback_model, self.fallback_api_key
            )
            fallback_kwargs["messages"] = messages
            if output_json:
                fallback_kwargs["response_format"] = {"type": "json_object"}

            logger.info(f"Falling back to: {fallback_model}")
            response = await acompletion(**fallback_kwargs)
            return response.choices[0].message.content or ""

    async def chat_json(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float | None = None,
    ) -> dict:
        """Send a chat completion and parse the response as JSON."""
        result = await self.chat(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            output_json=True,
            temperature=temperature,
        )
        # Strip markdown code fences if present
        result = result.strip()
        if result.startswith("```"):
            result = result.split("\n", 1)[-1]
            if result.endswith("```"):
                result = result[:-3]
        return json.loads(result.strip())


# Singleton instance
llm = LLMAdapter()
