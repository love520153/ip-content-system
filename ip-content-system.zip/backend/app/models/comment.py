"""Comment and interaction models — user comments & reply templates."""

import uuid
from datetime import datetime
from sqlalchemy import String, Text, Integer, DateTime, Enum as SAEnum, JSON, ForeignKey, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID
import enum

from app.database import Base


class CommentSentiment(str, enum.Enum):
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    NEGATIVE = "negative"
    QUESTION = "question"
    SUGGESTION = "suggestion"


class ReplyStatus(str, enum.Enum):
    PENDING = "pending"
    GENERATED = "generated"
    APPROVED = "approved"
    PUBLISHED = "published"
    REJECTED = "rejected"


class Comment(Base):
    """User comments fetched from platforms."""
    __tablename__ = "comments"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    platform: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    platform_comment_id: Mapped[str] = mapped_column(
        String(200), nullable=False, unique=True
    )
    platform_content_id: Mapped[str] = mapped_column(
        String(200), nullable=False, index=True
    )
    author_name: Mapped[str] = mapped_column(String(200), nullable=False)
    author_avatar: Mapped[str | None] = mapped_column(String(500), nullable=True)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    sentiment: Mapped[CommentSentiment] = mapped_column(
        SAEnum(CommentSentiment), default=CommentSentiment.NEUTRAL
    )
    like_count: Mapped[int] = mapped_column(Integer, default=0)
    reply_count: Mapped[int] = mapped_column(Integer, default=0)
    is_replied: Mapped[bool] = mapped_column(Boolean, default=False)
    reply_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    reply_status: Mapped[ReplyStatus] = mapped_column(
        SAEnum(ReplyStatus), default=ReplyStatus.PENDING
    )
    is_priority: Mapped[bool] = mapped_column(Boolean, default=False)

    # Raw metadata from platform
    metadata: Mapped[dict | None] = mapped_column(JSON, default=dict)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    replied_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    def __repr__(self) -> str:
        return f"<Comment {self.author_name}: {self.text[:30]}>"


class ReplyTemplate(Base):
    """Reusable reply templates for common comment types."""
    __tablename__ = "reply_templates"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    sentiment_type: Mapped[CommentSentiment] = mapped_column(
        SAEnum(CommentSentiment), nullable=False
    )
    platform: Mapped[str | None] = mapped_column(String(50), nullable=True)
    tone: Mapped[str] = mapped_column(String(50), default="friendly")  # friendly / professional / humorous / warm
    use_count: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )
