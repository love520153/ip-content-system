"""Workflow execution tracking models."""

import uuid
from datetime import datetime
from sqlalchemy import String, Text, Float, DateTime, Enum as SAEnum, JSON, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.dialects.postgresql import UUID
import enum

from app.database import Base


class WorkflowType(str, enum.Enum):
    TOPIC_RESEARCH = "topic_research"
    CONTENT_GENERATION = "content_generation"
    CONTENT_DISTRIBUTION = "content_distribution"
    COMMENT_RESPONSE = "comment_response"
    FULL_PIPELINE = "full_pipeline"


class WorkflowStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AgentRole(str, enum.Enum):
    TOPIC_RESEARCHER = "topic_researcher"
    CONTENT_CREATOR = "content_creator"
    DISTRIBUTOR = "distributor"
    COMMENT_MANAGER = "comment_manager"
    ORCHESTRATOR = "orchestrator"


class WorkflowRun(Base):
    """Tracks a workflow execution from start to finish."""
    __tablename__ = "workflow_runs"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    workflow_type: Mapped[WorkflowType] = mapped_column(
        SAEnum(WorkflowType), nullable=False
    )
    status: Mapped[WorkflowStatus] = mapped_column(
        SAEnum(WorkflowStatus), default=WorkflowStatus.PENDING, index=True
    )

    # What triggered this run
    trigger: Mapped[str] = mapped_column(String(100), default="manual")
    trigger_metadata: Mapped[dict | None] = mapped_column(JSON, default=dict)

    # Input / Output references
    input_data: Mapped[dict | None] = mapped_column(JSON, default=dict)
    output_summary: Mapped[dict | None] = mapped_column(JSON, default=dict)

    # Related entities
    topic_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("topics.id"), nullable=True
    )
    content_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("contents.id"), nullable=True
    )

    # Timing
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    duration_seconds: Mapped[float | None] = mapped_column(Float, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return f"<WorkflowRun {self.workflow_type.value} [{self.status.value}]>"


class AgentLog(Base):
    """Detailed logs of individual agent actions within a workflow."""
    __tablename__ = "agent_logs"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    workflow_run_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("workflow_runs.id"), nullable=False
    )
    agent_role: Mapped[AgentRole] = mapped_column(
        SAEnum(AgentRole), nullable=False
    )
    action: Mapped[str] = mapped_column(String(300), nullable=False)
    status: Mapped[str] = mapped_column(String(50), default="running")

    # Detailed data
    input_snapshot: Mapped[dict | None] = mapped_column(JSON, default=dict)
    output_snapshot: Mapped[dict | None] = mapped_column(JSON, default=dict)
    llm_call_count: Mapped[int] = mapped_column(default=0)
    tokens_used: Mapped[int] = mapped_column(default=0)
    reasoning: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    started_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    duration_ms: Mapped[int | None] = mapped_column(nullable=True)
