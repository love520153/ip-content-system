"""Topic research models — stores trending topics, analysis results."""

import uuid
from datetime import datetime
from sqlalchemy import String, Text, Float, Integer, DateTime, Enum as SAEnum, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID
import enum

from app.database import Base


class TopicStatus(str, enum.Enum):
    DRAFT = "draft"
    ANALYZING = "analyzing"
    READY = "ready"
    GENERATING = "generating"
    COMPLETED = "completed"
    ARCHIVED = "archived"


class TopicSource(str, enum.Enum):
    DOUYIN = "douyin"
    BILIBILI = "bilibili"
    XIAOHONGSHU = "xiaohongshu"
    WEIBO = "weibo"
    WECHAT = "wechat"
    MANUAL = "manual"
    AI_GENERATED = "ai_generated"


class Topic(Base):
    __tablename__ = "topics"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    keywords: Mapped[list[str]] = mapped_column(JSON, default=list)
    category: Mapped[str | None] = mapped_column(String(100), nullable=True)
    niche: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # Trend analysis
    trend_score: Mapped[float | None] = mapped_column(Float, default=0.0)
    competition_level: Mapped[str | None] = mapped_column(
        String(20), default="medium"
    )  # low / medium / high
    estimated_views: Mapped[int | None] = mapped_column(Integer, default=0)
    source: Mapped[TopicSource] = mapped_column(
        SAEnum(TopicSource), default=TopicSource.AI_GENERATED
    )
    source_url: Mapped[str | None] = mapped_column(String(1000), nullable=True)

    # Differentiation analysis
    differentiation_points: Mapped[list[str]] = mapped_column(JSON, default=list)
    target_audience: Mapped[str | None] = mapped_column(Text, nullable=True)
    content_angles: Mapped[list[str]] = mapped_column(JSON, default=list)

    # Status
    status: Mapped[TopicStatus] = mapped_column(
        SAEnum(TopicStatus), default=TopicStatus.DRAFT, index=True
    )
    platform_suitability: Mapped[dict | None] = mapped_column(JSON, default=dict)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    # Relationships
    contents = relationship("Content", back_populates="topic", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Topic {self.title[:30]}>"
