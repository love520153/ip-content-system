"""Content generation models — scripts, copy, livestream scripts."""

import uuid
from datetime import datetime
from sqlalchemy import String, Text, Integer, DateTime, Enum as SAEnum, JSON, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID
import enum

from app.database import Base


class ContentType(str, enum.Enum):
    SHORT_VIDEO_SCRIPT = "short_video_script"
    IMAGE_TEXT_POST = "image_text_post"
    LIVESTREAM_SCRIPT = "livestream_script"
    ARTICLE = "article"
    PODCAST_SCRIPT = "podcast_script"


class ContentStatus(str, enum.Enum):
    DRAFT = "draft"
    GENERATING = "generating"
    COMPLETED = "completed"
    FAILED = "failed"
    PUBLISHED = "published"


class PlatformTarget(str, enum.Enum):
    DOUYIN = "douyin"
    BILIBILI = "bilibili"
    XIAOHONGSHU = "xiaohongshu"
    WECHAT = "wechat"
    WEIBO = "weibo"
    ALL = "all"


class Content(Base):
    __tablename__ = "contents"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    topic_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("topics.id"), nullable=False
    )
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    content_type: Mapped[ContentType] = mapped_column(
        SAEnum(ContentType), nullable=False
    )

    # Main content body
    body: Mapped[str | None] = mapped_column(Text, nullable=True)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Platform adaptation
    platform_target: Mapped[PlatformTarget] = mapped_column(
        SAEnum(PlatformTarget), default=PlatformTarget.ALL
    )
    hashtags: Mapped[list[str]] = mapped_column(JSON, default=list)
    seo_keywords: Mapped[list[str]] = mapped_column(JSON, default=list)

    # Media
    cover_image_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)
    suggested_music: Mapped[str | None] = mapped_column(String(300), nullable=True)

    # Status
    status: Mapped[ContentStatus] = mapped_column(
        SAEnum(ContentStatus), default=ContentStatus.DRAFT, index=True
    )
    quality_score: Mapped[int | None] = mapped_column(Integer, default=0)
    feedback: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    # Relationships
    topic = relationship("Topic", back_populates="contents")
    variants = relationship("ContentVariant", back_populates="content", cascade="all, delete-orphan")
    published_entries = relationship("PublishedContent", back_populates="content", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Content {self.title[:30]} ({self.content_type.value})>"


class ContentVariant(Base):
    """Platform-specific adaptations of a piece of content."""
    __tablename__ = "content_variants"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    content_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("contents.id"), nullable=False
    )
    platform: Mapped[str] = mapped_column(String(50), nullable=False)
    adapted_body: Mapped[str | None] = mapped_column(Text, nullable=True)
    adapted_title: Mapped[str | None] = mapped_column(String(500), nullable=True)
    hashtags: Mapped[list[str]] = mapped_column(JSON, default=list)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )

    content = relationship("Content", back_populates="variants")
