import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  timeout: 120000,  // 2 minutes for long-running agent tasks
  headers: {
    'Content-Type': 'application/json',
  },
});

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const message = error.response?.data?.detail || error.message || '请求失败';
    console.error('API Error:', message);
    return Promise.reject(new Error(message));
  }
);

// ── Types ──────────────────────────────────────────────────────

export interface Topic {
  id: string;
  title: string;
  description?: string;
  keywords: string[];
  category?: string;
  niche?: string;
  trend_score?: number;
  competition_level?: string;
  source: string;
  differentiation_points: string[];
  target_audience?: string;
  content_angles: string[];
  status: string;
  platform_suitability?: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface Content {
  id: string;
  topic_id: string;
  title: string;
  content_type: string;
  body?: string;
  summary?: string;
  platform_target: string;
  hashtags: string[];
  seo_keywords: string[];
  cover_image_prompt?: string;
  status: string;
  quality_score?: number;
  created_at: string;
  updated_at: string;
  variants: ContentVariant[];
}

export interface ContentVariant {
  id: string;
  platform: string;
  adapted_body?: string;
  adapted_title?: string;
  hashtags: string[];
  notes?: string;
  created_at: string;
}

export interface WorkflowRun {
  id: string;
  workflow_type: string;
  status: string;
  trigger: string;
  started_at?: string;
  completed_at?: string;
  duration_seconds?: number;
  error_message?: string;
  output_summary?: Record<string, unknown>;
}

export interface DashboardStats {
  total_topics: number;
  total_contents: number;
  total_published: number;
  total_comments: number;
  pending_replies: number;
  active_accounts: number;
  avg_quality_score: number;
  recent_runs: WorkflowRun[];
}

export interface PlatformAccount {
  id: string;
  platform: string;
  account_name: string;
  followers_count: number;
  is_active: boolean;
}

// ── API Functions ──────────────────────────────────────────────

// Topics
export const topicsApi = {
  list: (params?: { page?: number; page_size?: number; status?: string; niche?: string }) =>
    api.get<{ items: Topic[]; total: number }>('/topics', { params }),

  get: (id: string) => api.get<Topic>(`/topics/${id}`),

  create: (data: { title: string; description?: string; keywords?: string[]; category?: string; niche?: string }) =>
    api.post<Topic>('/topics', data),

  analyze: (data: { niche: string; keywords?: string[]; count?: number; platforms?: string[] }) =>
    api.post<{ topics: Topic[]; workflow_run_id?: string }>('/topics/analyze', data),

  delete: (id: string) => api.delete(`/topics/${id}`),
};

// Contents
export const contentsApi = {
  list: (params?: { page?: number; page_size?: number; topic_id?: string; content_type?: string }) =>
    api.get<{ items: Content[]; total: number }>('/contents', { params }),

  get: (id: string) => api.get<Content>(`/contents/${id}`),

  generate: (data: { topic_id: string; content_type?: string; platform_targets?: string[]; tone?: string }) =>
    api.post('/contents/generate', data),
};

// Workflows
export const workflowsApi = {
  list: (params?: { page?: number; page_size?: number }) =>
    api.get<{ items: WorkflowRun[]; total: number }>('/workflows', { params }),

  get: (id: string) => api.get(`/workflows/${id}`),

  runFullPipeline: (data: {
    niche: string;
    keywords?: string[];
    content_type?: string;
    platforms?: string[];
    auto_publish?: boolean;
    tone?: string;
  }) => api.post('/workflows/full-pipeline', data),

  runTopicResearch: (data: { niche: string; keywords?: string[]; platforms?: string[] }) =>
    api.post('/workflows/topic-research', data),

  getDashboard: () => api.get<DashboardStats>('/workflows/stats/dashboard'),
};

// Platforms
export const platformsApi = {
  listAccounts: () => api.get<{ items: PlatformAccount[]; total: number }>('/platforms/accounts'),

  listPublished: (params?: { page?: number; page_size?: number }) =>
    api.get<{ items: unknown[]; total: number }>('/platforms/published', { params }),

  listComments: (params?: { page?: number; platform?: string; sentiment?: string }) =>
    api.get<{ items: unknown[]; total: number }>('/platforms/comments', { params }),

  publishContent: (contentId: string, autoPublish = false) =>
    api.post(`/platforms/publish/${contentId}`, null, { params: { auto_publish: autoPublish } }),

  analyzeComments: (contentId: string) =>
    api.post(`/platforms/comments/analyze/${contentId}`),

  getSchedule: (params?: { content_type?: string; platforms?: string }) =>
    api.get('/platforms/schedule', { params }),
};

// Health
export const healthApi = {
  check: () => api.get('/health'),
  config: () => api.get('/config'),
};

export default api;
