import React, { useEffect, useState } from 'react';
import {
  Lightbulb,
  Search,
  Plus,
  Trash2,
  TrendingUp,
  Target,
  Users,
  Hash,
  Sparkles,
  AlertCircle,
} from 'lucide-react';
import { topicsApi, Topic } from '../api/client';

export default function Topics() {
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [niche, setNiche] = useState('');
  const [keywords, setKeywords] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadTopics();
  }, []);

  const loadTopics = async () => {
    try {
      const res = await topicsApi.list({ page_size: 50 });
      setTopics(res.data.items);
    } catch {
      // Service may be down
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyze = async () => {
    if (!niche.trim()) return;
    setAnalyzing(true);
    setError(null);
    try {
      const res = await topicsApi.analyze({
        niche: niche.trim(),
        keywords: keywords.split(',').map((k) => k.trim()).filter(Boolean),
      });
      // Refresh list
      await loadTopics();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : '分析失败';
      setError(message);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await topicsApi.delete(id);
      setTopics((prev) => prev.filter((t) => t.id !== id));
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">选题管理</h1>
          <p className="text-gray-500 mt-1">AI 驱动的热点分析与差异化选题生成</p>
        </div>
      </div>

      {/* AI Analysis Input */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-primary-600" />
          <h2 className="font-semibold text-gray-800">AI 选题调研</h2>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            className="input-field flex-1"
            placeholder="输入内容赛道，如：职场干货、Python 教学、健身科普..."
            value={niche}
            onChange={(e) => setNiche(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAnalyze()}
          />
          <input
            className="input-field sm:w-48"
            placeholder="关键词（逗号分隔）"
            value={keywords}
            onChange={(e) => setKeywords(e.target.value)}
          />
          <button
            className="btn-primary flex items-center gap-2"
            onClick={handleAnalyze}
            disabled={analyzing || !niche.trim()}
          >
            {analyzing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                分析中...
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                AI 分析
              </>
            )}
          </button>
        </div>
        {error && (
          <div className="mt-3 flex items-center gap-2 text-sm text-red-600">
            <AlertCircle className="w-4 h-4" />
            {error}
          </div>
        )}
      </div>

      {/* Topics Grid */}
      {loading ? (
        <div className="text-center py-12 text-gray-400">加载中...</div>
      ) : topics.length === 0 ? (
        <div className="card text-center py-12">
          <Lightbulb className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">暂无选题，使用 AI 分析生成你的第一个选题</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {topics.map((topic) => (
            <div key={topic.id} className="card hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <h3 className="font-semibold text-gray-800 line-clamp-2">{topic.title}</h3>
                <button
                  onClick={() => handleDelete(topic.id)}
                  className="p-1 hover:bg-red-50 rounded text-gray-400 hover:text-red-500"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {topic.description && (
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{topic.description}</p>
              )}

              <div className="flex flex-wrap gap-2 mb-3">
                {topic.keywords.map((kw, i) => (
                  <span key={i} className="badge-gray text-xs">
                    <Hash className="w-3 h-3 inline mr-0.5" />
                    {kw}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-4 text-xs text-gray-500">
                {topic.trend_score !== null && (
                  <span className="flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
                    热度 {topic.trend_score?.toFixed(0)}
                  </span>
                )}
                <span className="flex items-center gap-1">
                  <Target className="w-3.5 h-3.5" />
                  {topic.competition_level === 'low' ? '蓝海' : topic.competition_level === 'high' ? '红海' : '中等'}
                </span>
                {topic.content_angles.length > 0 && (
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" />
                    {topic.content_angles.length} 个角度
                  </span>
                )}
              </div>

              {topic.differentiation_points.length > 0 && (
                <div className="mt-3 pt-3 border-t border-gray-100">
                  <p className="text-xs text-gray-400 mb-1">差异化切入点：</p>
                  <div className="flex flex-wrap gap-1">
                    {topic.differentiation_points.map((dp, i) => (
                      <span key={i} className="badge-green text-xs">{dp}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
