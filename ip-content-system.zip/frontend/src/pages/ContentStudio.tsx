import React, { useEffect, useState } from 'react';
import {
  FileText,
  Video,
  Image,
  Radio,
  Sparkles,
  Copy,
  Check,
  Send,
  Hash,
  BookOpen,
} from 'lucide-react';
import { contentsApi, topicsApi, Content, Topic } from '../api/client';

const contentTypes = [
  { value: 'short_video_script', label: '短视频脚本', icon: Video },
  { value: 'image_text_post', label: '图文笔记', icon: Image },
  { value: 'livestream_script', label: '直播话术', icon: Radio },
  { value: 'article', label: '深度文章', icon: BookOpen },
];

export default function ContentStudio() {
  const [contents, setContents] = useState<Content[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTopic, setSelectedTopic] = useState('');
  const [contentType, setContentType] = useState('short_video_script');
  const [tone, setTone] = useState('专业易懂');
  const [generating, setGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<Content | null>(null);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [cRes, tRes] = await Promise.all([
        contentsApi.list({ page_size: 20 }),
        topicsApi.list({ page_size: 50 }),
      ]);
      setContents(cRes.data.items);
      setTopics(tRes.data.items);
    } catch {
      // offline
    } finally {
      setLoading(false);
    }
  };

  const handleGenerate = async () => {
    if (!selectedTopic) return;
    setGenerating(true);
    setGeneratedContent(null);
    setError(null);
    try {
      const res = await contentsApi.generate({
        topic_id: selectedTopic,
        content_type: contentType,
        tone,
      });
      if (res.data.content) {
        setGeneratedContent(res.data.content);
      }
      // Refresh list
      const cRes = await contentsApi.list({ page_size: 20 });
      setContents(cRes.data.items);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : '生成失败');
    } finally {
      setGenerating(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getTypeIcon = (type: string) => {
    const found = contentTypes.find((ct) => ct.value === type);
    return found?.icon || FileText;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">内容工坊</h1>
          <p className="text-gray-500 mt-1">AI 驱动的多平台内容智能生成</p>
        </div>
      </div>

      {/* Generation Form */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-primary-600" />
          <h2 className="font-semibold text-gray-800">智能内容生成</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">选择选题</label>
            <select
              className="input-field"
              value={selectedTopic}
              onChange={(e) => setSelectedTopic(e.target.value)}
            >
              <option value="">请选择...</option>
              {topics.map((t) => (
                <option key={t.id} value={t.id}>{t.title.slice(0, 40)}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">内容类型</label>
            <div className="flex flex-wrap gap-2">
              {contentTypes.map(({ value, label, icon: Icon }) => (
                <button
                  key={value}
                  onClick={() => setContentType(value)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors
                    ${contentType === value
                      ? 'bg-primary-100 text-primary-700 ring-1 ring-primary-300'
                      : 'bg-gray-50 text-gray-600 hover:bg-gray-100'}`}
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">创作风格</label>
            <select
              className="input-field"
              value={tone}
              onChange={(e) => setTone(e.target.value)}
            >
              <option>专业易懂</option>
              <option>轻松有趣</option>
              <option>深度干货</option>
              <option>情感共鸣</option>
              <option>实战教程</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              className="btn-primary flex items-center gap-2 w-full"
              onClick={handleGenerate}
              disabled={generating || !selectedTopic}
            >
              {generating ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  生成中...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  AI 生成
                </>
              )}
            </button>
          </div>
        </div>

        {error && (
          <div className="text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</div>
        )}

        {/* Generated Content Preview */}
        {generatedContent && (
          <div className="mt-4 p-4 bg-gray-50 rounded-xl border border-gray-200">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-gray-800">{generatedContent.title}</h3>
              <button
                onClick={() => handleCopy(generatedContent.body || '')}
                className="btn-secondary flex items-center gap-1.5 text-sm"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                {copied ? '已复制' : '复制全文'}
              </button>
            </div>

            <div className="text-sm text-gray-700 whitespace-pre-wrap max-h-96 overflow-y-auto">
              {generatedContent.body}
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {generatedContent.hashtags.map((tag, i) => (
                <span key={i} className="badge-blue text-xs">
                  <Hash className="w-3 h-3 inline mr-0.5" />
                  {tag.replace('#', '')}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Content History */}
      <div>
        <h3 className="font-semibold text-gray-800 mb-4">历史内容</h3>
        {loading ? (
          <div className="text-center py-8 text-gray-400">加载中...</div>
        ) : contents.length === 0 ? (
          <div className="card text-center py-8">
            <FileText className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">暂无生成内容</p>
          </div>
        ) : (
          <div className="space-y-3">
            {contents.map((content) => {
              const TypeIcon = getTypeIcon(content.content_type);
              return (
                <div key={content.id} className="card flex items-start gap-4">
                  <div className="p-2 rounded-lg bg-gray-100">
                    <TypeIcon className="w-5 h-5 text-gray-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-gray-800 truncate">{content.title}</h4>
                    <div className="flex items-center gap-3 text-xs text-gray-400 mt-1">
                      <span>{contentTypes.find((ct) => ct.value === content.content_type)?.label}</span>
                      {content.quality_score && (
                        <span className="text-emerald-600">质量评分: {content.quality_score}</span>
                      )}
                      <span>{new Date(content.created_at).toLocaleDateString('zh-CN')}</span>
                    </div>
                    {content.variants.length > 0 && (
                      <div className="flex gap-1 mt-2">
                        {content.variants.map((v) => (
                          <span key={v.id} className="badge-gray text-xs">{v.platform}</span>
                        ))}
                      </div>
                    )}
                  </div>
                  <button
                    onClick={() => handleCopy(content.body || '')}
                    className="p-2 hover:bg-gray-100 rounded-lg"
                  >
                    <Copy className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
