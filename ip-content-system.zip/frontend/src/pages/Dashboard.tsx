import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Lightbulb,
  FileText,
  Share2,
  MessageSquare,
  TrendingUp,
  Clock,
  Play,
  Sparkles,
  ArrowRight,
  Workflow,
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { workflowsApi, DashboardStats } from '../api/client';

const defaultStats: DashboardStats = {
  total_topics: 0, total_contents: 0, total_published: 0,
  total_comments: 0, pending_replies: 0, active_accounts: 0,
  avg_quality_score: 0, recent_runs: [],
};

const chartData = [
  { name: '周一', 内容: 2, 互动: 15 },
  { name: '周二', 内容: 3, 互动: 22 },
  { name: '周三', 内容: 1, 互动: 18 },
  { name: '周四', 内容: 4, 互动: 30 },
  { name: '周五', 内容: 3, 互动: 25 },
  { name: '周六', 内容: 5, 互动: 40 },
  { name: '周日', 内容: 2, 互动: 28 },
];

const statusColors: Record<string, string> = {
  completed: 'text-emerald-600 bg-emerald-50',
  running: 'text-blue-600 bg-blue-50',
  failed: 'text-red-600 bg-red-50',
  pending: 'text-gray-600 bg-gray-50',
};

const statusLabels: Record<string, string> = {
  completed: '已完成',
  running: '运行中',
  failed: '失败',
  pending: '等待中',
};

export default function Dashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats>(defaultStats);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      setError(null);
      const res = await workflowsApi.getDashboard();
      setStats(res.data);
    } catch (err) {
      setError('无法连接到后端服务，请确认服务已启动。显示示例数据。');
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    {
      label: '选题总数',
      value: stats.total_topics,
      icon: Lightbulb,
      color: 'text-amber-600 bg-amber-50',
      link: '/topics',
    },
    {
      label: '内容产出',
      value: stats.total_contents,
      icon: FileText,
      color: 'text-blue-600 bg-blue-50',
      link: '/content',
    },
    {
      label: '已发布',
      value: stats.total_published,
      icon: Share2,
      color: 'text-emerald-600 bg-emerald-50',
      link: '/publish',
    },
    {
      label: '待回复评论',
      value: stats.pending_replies,
      icon: MessageSquare,
      color: 'text-purple-600 bg-purple-50',
      link: '/publish',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">内容工厂仪表盘</h1>
          <p className="text-gray-500 mt-1">实时监控内容生产管线运行状态</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={loadStats}
            className="btn-secondary flex items-center gap-2"
          >
            <Clock className="w-4 h-4" />
            刷新
          </button>
          <button
            onClick={() => navigate('/workflow')}
            className="btn-primary flex items-center gap-2"
          >
            <Play className="w-4 h-4" />
            启动全流程
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-amber-700 text-sm">
          {error}
        </div>
      )}

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map(({ label, value, icon: Icon, color, link }) => (
          <div
            key={label}
            onClick={() => navigate(link)}
            className="stat-card cursor-pointer hover:shadow-md transition-shadow"
          >
            <div className={`p-3 rounded-xl ${color}`}>
              <Icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-800">{value}</p>
              <p className="text-sm text-gray-500">{label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Charts & Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Performance Chart */}
        <div className="card lg:col-span-2">
          <h3 className="font-semibold text-gray-800 mb-4">本周内容生产趋势</h3>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" stroke="#9ca3af" fontSize={12} />
              <YAxis stroke="#9ca3af" fontSize={12} />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="内容"
                stroke="#3b82f6"
                strokeWidth={2}
                dot={{ fill: '#3b82f6', r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="互动"
                stroke="#8b5cf6"
                strokeWidth={2}
                dot={{ fill: '#8b5cf6', r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Quick Actions */}
        <div className="space-y-4">
          {/* AI Quick Start */}
          <div className="card">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-primary-600" />
              <h3 className="font-semibold text-gray-800">AI 快捷操作</h3>
            </div>
            <div className="space-y-3">
              <button
                onClick={() => navigate('/topics')}
                className="w-full text-left flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Lightbulb className="w-4 h-4 text-amber-500" />
                  <span className="text-sm font-medium text-gray-700">AI 选题调研</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-400" />
              </button>
              <button
                onClick={() => navigate('/content')}
                className="w-full text-left flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <FileText className="w-4 h-4 text-blue-500" />
                  <span className="text-sm font-medium text-gray-700">智能内容生成</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-400" />
              </button>
              <button
                onClick={() => navigate('/workflow')}
                className="w-full text-left flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Workflow className="w-4 h-4 text-purple-500" />
                  <span className="text-sm font-medium text-gray-700">全自动生产管线</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-400" />
              </button>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="card">
            <h3 className="font-semibold text-gray-800 mb-4">最近运行记录</h3>
            {stats.recent_runs.length === 0 ? (
              <p className="text-sm text-gray-400">暂无运行记录</p>
            ) : (
              <div className="space-y-3">
                {stats.recent_runs.slice(0, 4).map((run) => (
                  <div key={run.id} className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-700">
                        {run.workflow_type === 'full_pipeline' ? '全流程管线' :
                         run.workflow_type === 'topic_research' ? '选题调研' : '内容生成'}
                      </p>
                      <p className="text-xs text-gray-400">
                        {run.duration_seconds ? `${run.duration_seconds.toFixed(1)}秒` : '处理中...'}
                      </p>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                      statusColors[run.status] || 'text-gray-600 bg-gray-50'
                    }`}>
                      {statusLabels[run.status] || run.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* System Status */}
      <div className="card">
        <h3 className="font-semibold text-gray-800 mb-4">系统概览</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100/50 rounded-xl">
            <TrendingUp className="w-5 h-5 text-blue-600 mx-auto mb-2" />
            <p className="text-xs text-gray-500">月均产出提升</p>
            <p className="text-lg font-bold text-blue-700">4x</p>
          </div>
          <div className="p-4 bg-gradient-to-br from-emerald-50 to-emerald-100/50 rounded-xl">
            <Clock className="w-5 h-5 text-emerald-600 mx-auto mb-2" />
            <p className="text-xs text-gray-500">单条耗时</p>
            <p className="text-lg font-bold text-emerald-700">30min</p>
          </div>
          <div className="p-4 bg-gradient-to-br from-purple-50 to-purple-100/50 rounded-xl">
            <MessageSquare className="w-5 h-5 text-purple-600 mx-auto mb-2" />
            <p className="text-xs text-gray-500">互动率提升</p>
            <p className="text-lg font-bold text-purple-700">+35%</p>
          </div>
          <div className="p-4 bg-gradient-to-br from-amber-50 to-amber-100/50 rounded-xl">
            <TrendingUp className="w-5 h-5 text-amber-600 mx-auto mb-2" />
            <p className="text-xs text-gray-500">月均涨粉提升</p>
            <p className="text-lg font-bold text-amber-700">+50%</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// Need to import Workflow for the icon in quick actions
