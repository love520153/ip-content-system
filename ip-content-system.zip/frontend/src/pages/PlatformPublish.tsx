import React, { useEffect, useState } from 'react';
import {
  Share2,
  Globe,
  MessageSquare,
  Send,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
} from 'lucide-react';
import { platformsApi, contentsApi, Content } from '../api/client';

const platformIcons: Record<string, string> = {
  douyin: '🎵',
  bilibili: '📺',
  xiaohongshu: '📕',
  wechat: '💬',
  weibo: '📱',
};

const platformNames: Record<string, string> = {
  douyin: '抖音',
  bilibili: 'B站',
  xiaohongshu: '小红书',
  wechat: '微信公众号',
  weibo: '微博',
};

export default function PlatformPublish() {
  const [contents, setContents] = useState<Content[]>([]);
  const [published, setPublished] = useState<unknown[]>([]);
  const [comments, setComments] = useState<unknown[]>([]);
  const [selectedContent, setSelectedContent] = useState('');
  const [publishing, setPublishing] = useState(false);
  const [autoPublish, setAutoPublish] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'publish' | 'comments' | 'history'>('publish');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [cRes, pRes, cmRes] = await Promise.all([
        contentsApi.list({ page_size: 50 }),
        platformsApi.listPublished(),
        platformsApi.listComments({ page: 1 }),
      ]);
      setContents(cRes.data.items);
      setPublished(pRes.data.items);
      setComments(cmRes.data.items);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  const handlePublish = async () => {
    if (!selectedContent) return;
    setPublishing(true);
    setMessage(null);
    try {
      const res = await platformsApi.publishContent(selectedContent, autoPublish);
      setMessage({ type: 'success', text: `内容已${autoPublish ? '发布' : '准备'}到 ${res.data.published.length} 个平台` });
      await loadData();
    } catch (err: unknown) {
      setMessage({ type: 'error', text: err instanceof Error ? err.message : '发布失败' });
    } finally {
      setPublishing(false);
    }
  };

  const handleAnalyzeComments = async (contentId: string) => {
    setMessage(null);
    try {
      const res = await platformsApi.analyzeComments(contentId);
      setMessage({ type: 'success', text: `已处理 ${res.data.processed} 条评论` });
      await loadData();
    } catch (err: unknown) {
      setMessage({ type: 'error', text: err instanceof Error ? err.message : '分析失败' });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">分发与互动</h1>
          <p className="text-gray-500 mt-1">多平台内容分发 & 智能评论管理</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-xl w-fit">
        {([
          { key: 'publish', label: '内容发布', icon: Send },
          { key: 'comments', label: '评论管理', icon: MessageSquare },
          { key: 'history', label: '发布历史', icon: Clock },
        ] as const).map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key as typeof activeTab)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors
              ${activeTab === key ? 'bg-white shadow-sm text-gray-800' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {message && (
        <div className={`flex items-center gap-2 p-3 rounded-lg text-sm ${
          message.type === 'success' ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'
        }`}>
          {message.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {message.text}
        </div>
      )}

      {/* Publish Tab */}
      {activeTab === 'publish' && (
        <div className="card">
          <h3 className="font-semibold text-gray-800 mb-4">发布内容到平台</h3>
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <select
              className="input-field flex-1"
              value={selectedContent}
              onChange={(e) => setSelectedContent(e.target.value)}
            >
              <option value="">选择要发布的内容...</option>
              {contents.filter((c) => c.status === 'completed' || c.status === 'draft').map((c) => (
                <option key={c.id} value={c.id}>{c.title.slice(0, 50)}</option>
              ))}
            </select>
            <label className="flex items-center gap-2 text-sm text-gray-600">
              <input
                type="checkbox"
                checked={autoPublish}
                onChange={(e) => setAutoPublish(e.target.checked)}
                className="rounded"
              />
              真实发布
            </label>
            <button
              className="btn-primary flex items-center gap-2"
              onClick={handlePublish}
              disabled={publishing || !selectedContent}
            >
              {publishing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  处理中...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  {autoPublish ? '发布到平台' : '准备分发'}
                </>
              )}
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {['douyin', 'bilibili', 'xiaohongshu', 'wechat'].map((platform) => (
              <div key={platform} className="p-4 bg-gray-50 rounded-xl text-center">
                <span className="text-2xl">{platformIcons[platform]}</span>
                <p className="text-sm font-medium text-gray-700 mt-1">{platformNames[platform]}</p>
                <p className="text-xs text-gray-400 mt-0.5">支持自动发布</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Comments Tab */}
      {activeTab === 'comments' && (
        <div className="card">
          <h3 className="font-semibold text-gray-800 mb-4">评论管理与 AI 回复</h3>
          <p className="text-sm text-gray-500 mb-4">选择内容进行评论分析和 AI 回复生成（当前为模拟数据）</p>

          <select
            className="input-field mb-4"
            value={selectedContent}
            onChange={(e) => setSelectedContent(e.target.value)}
          >
            <option value="">选择内容分析评论...</option>
            {contents.map((c) => (
              <option key={c.id} value={c.id}>{c.title.slice(0, 50)}</option>
            ))}
          </select>

          <button
            className="btn-primary flex items-center gap-2"
            onClick={() => {
              if (selectedContent) handleAnalyzeComments(selectedContent);
            }}
            disabled={!selectedContent}
          >
            <MessageSquare className="w-4 h-4" />
            AI 分析并生成回复
          </button>

          {comments.length > 0 && (
            <div className="mt-6 space-y-3">
              <h4 className="text-sm font-medium text-gray-700">最近评论</h4>
              {(comments as Array<{
                id: string; author_name: string; text: string;
                sentiment: string; reply_text: string; is_replied: boolean;
              }>).map((comment) => (
                <div key={comment.id} className="p-3 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-sm text-gray-800">{comment.author_name}</span>
                    <span className={`badge text-xs ${
                      comment.sentiment === 'positive' ? 'badge-green' :
                      comment.sentiment === 'negative' ? 'badge-red' : 'badge-gray'
                    }`}>{comment.sentiment}</span>
                  </div>
                  <p className="text-sm text-gray-600">{comment.text}</p>
                  {comment.is_replied && comment.reply_text && (
                    <div className="mt-2 pl-3 border-l-2 border-primary-300">
                      <p className="text-xs text-primary-600 mb-0.5">AI 回复：</p>
                      <p className="text-sm text-gray-700">{comment.reply_text}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* History Tab */}
      {activeTab === 'history' && (
        <div className="card">
          <h3 className="font-semibold text-gray-800 mb-4">发布历史</h3>
          {loading ? (
            <div className="text-center py-8 text-gray-400">加载中...</div>
          ) : published.length === 0 ? (
            <div className="text-center py-8">
              <Globe className="w-10 h-10 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">暂无发布记录</p>
            </div>
          ) : (
            <div className="space-y-3">
              {(published as Array<{
                id: string; platform: string; status: string;
                url?: string; views: number; likes: number;
              }>).map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{platformIcons[item.platform] || '🌐'}</span>
                    <div>
                      <p className="text-sm font-medium text-gray-800">
                        {platformNames[item.platform] || item.platform}
                      </p>
                      {item.url && (
                        <a href={item.url} target="_blank" rel="noreferrer"
                          className="text-xs text-primary-600 hover:underline">查看</a>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs text-gray-400">{item.views} 浏览</span>
                    <span className="text-xs text-gray-400">{item.likes} 点赞</span>
                    {item.status === 'published' ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    ) : item.status === 'failed' ? (
                      <XCircle className="w-5 h-5 text-red-500" />
                    ) : (
                      <Clock className="w-5 h-5 text-amber-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
