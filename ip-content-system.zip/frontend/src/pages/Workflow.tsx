import React, { useEffect, useState } from 'react';
import {
  Workflow as WorkflowIcon,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Clock,
  Loader2,
  Sparkles,
  ChevronDown,
  ChevronRight,
  AlertCircle,
} from 'lucide-react';
import { workflowsApi, WorkflowRun } from '../api/client';

const statusConfig: Record<string, { icon: React.ReactNode; label: string; color: string }> = {
  completed: { icon: <CheckCircle2 className="w-4 h-4" />, label: '已完成', color: 'text-emerald-600 bg-emerald-50 border-emerald-200' },
  running: { icon: <Loader2 className="w-4 h-4 animate-spin" />, label: '运行中', color: 'text-blue-600 bg-blue-50 border-blue-200' },
  failed: { icon: <XCircle className="w-4 h-4" />, label: '失败', color: 'text-red-600 bg-red-50 border-red-200' },
  pending: { icon: <Clock className="w-4 h-4" />, label: '等待中', color: 'text-gray-600 bg-gray-50 border-gray-200' },
};

const workflowTypeLabels: Record<string, string> = {
  full_pipeline: '全流程管线',
  topic_research: '选题调研',
  content_generation: '内容生成',
  content_distribution: '内容分发',
  comment_response: '评论互动',
};

export default function WorkflowPage() {
  const [runs, setRuns] = useState<WorkflowRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedRun, setExpandedRun] = useState<string | null>(null);
  const [runDetail, setRunDetail] = useState<Record<string, unknown> | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  // Form state
  const [niche, setNiche] = useState('');
  const [keywords, setKeywords] = useState('');
  const [contentType, setContentType] = useState('short_video_script');
  const [autoPublish, setAutoPublish] = useState(false);
  const [tone, setTone] = useState('专业易懂');

  useEffect(() => {
    loadRuns();
  }, []);

  const loadRuns = async () => {
    try {
      const res = await workflowsApi.list({ page_size: 20 });
      setRuns(res.data.items);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  const handleRunPipeline = async () => {
    if (!niche.trim()) return;
    setRunning(true);
    setError(null);
    try {
      const res = await workflowsApi.runFullPipeline({
        niche: niche.trim(),
        keywords: keywords.split(',').map((k) => k.trim()).filter(Boolean),
        content_type: contentType,
        auto_publish: autoPublish,
        tone,
      });
      await loadRuns();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : '流程执行失败');
    } finally {
      setRunning(false);
    }
  };

  const handleViewDetail = async (runId: string) => {
    if (expandedRun === runId) {
      setExpandedRun(null);
      setRunDetail(null);
      return;
    }
    setExpandedRun(runId);
    setDetailLoading(true);
    try {
      const res = await workflowsApi.get(runId);
      setRunDetail(res.data);
    } catch {
      setRunDetail(null);
    } finally {
      setDetailLoading(false);
    }
  };

  const getPhaseSteps = (run: WorkflowRun) => {
    const details = run.output_summary;
    return details && typeof details === 'object' && 'steps' in details
      ? (details as Record<string, unknown>).steps as Array<Record<string, unknown>>
      : [];
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">全自动生产管线</h1>
          <p className="text-gray-500 mt-1">多 Agent 协作：选题 → 内容 → 分发 → 互动</p>
        </div>
      </div>

      {/* Pipeline Configuration */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <WorkflowIcon className="w-5 h-5 text-primary-600" />
          <h2 className="font-semibold text-gray-800">启动生产管线</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">内容赛道 *</label>
            <input
              className="input-field"
              placeholder="如：职场干货、Python教学"
              value={niche}
              onChange={(e) => setNiche(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">关键词</label>
            <input
              className="input-field"
              placeholder="逗号分隔"
              value={keywords}
              onChange={(e) => setKeywords(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">内容类型</label>
            <select
              className="input-field"
              value={contentType}
              onChange={(e) => setContentType(e.target.value)}
            >
              <option value="short_video_script">短视频脚本</option>
              <option value="image_text_post">图文笔记</option>
              <option value="livestream_script">直播话术</option>
              <option value="article">深度文章</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">创作风格</label>
            <select className="input-field" value={tone} onChange={(e) => setTone(e.target.value)}>
              <option>专业易懂</option>
              <option>轻松有趣</option>
              <option>深度干货</option>
              <option>情感共鸣</option>
            </select>
          </div>
          <div className="flex items-end">
            <label className="flex items-center gap-2 text-sm text-gray-600 mb-1">
              <input
                type="checkbox"
                checked={autoPublish}
                onChange={(e) => setAutoPublish(e.target.checked)}
                className="rounded"
              />
              完成后自动发布
            </label>
          </div>
          <div className="flex items-end">
            <button
              className="btn-primary flex items-center gap-2 w-full"
              onClick={handleRunPipeline}
              disabled={running || !niche.trim()}
            >
              {running ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  执行中...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  启动全流程
                </>
              )}
            </button>
          </div>
        </div>

        {error && (
          <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 p-3 rounded-lg">
            <AlertCircle className="w-4 h-4" />
            {error}
          </div>
        )}

        {/* Pipeline Visualization */}
        <div className="mt-4 grid grid-cols-4 gap-2">
          {[
            { step: '1', label: '选题调研', agent: 'TopicResearch Agent', icon: Sparkles },
            { step: '2', label: '内容生成', agent: 'ContentGen Agent', icon: Sparkles },
            { step: '3', label: '分发展示', agent: 'Distribution Agent', icon: Sparkles },
            { step: '4', label: '评论互动', agent: 'Interaction Agent', icon: Sparkles },
          ].map(({ step, label, agent, icon: Icon }) => (
            <div key={step} className="text-center p-3 bg-gradient-to-b from-gray-50 to-gray-100/50 rounded-xl">
              <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center mx-auto mb-2 text-sm font-bold">
                {step}
              </div>
              <p className="text-sm font-medium text-gray-800">{label}</p>
              <p className="text-xs text-gray-400 mt-0.5">{agent}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Run History */}
      <div>
        <h3 className="font-semibold text-gray-800 mb-4">运行历史</h3>
        {loading ? (
          <div className="text-center py-8 text-gray-400">加载中...</div>
        ) : runs.length === 0 ? (
          <div className="card text-center py-8">
            <WorkflowIcon className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">暂无运行记录，启动一次全流程管线吧</p>
          </div>
        ) : (
          <div className="space-y-3">
            {runs.map((run) => {
              const sc = statusConfig[run.status] || statusConfig.pending;
              const phases = getPhaseSteps(run);
              const isExpanded = expandedRun === run.id;

              return (
                <div key={run.id} className="card">
                  <div
                    className="flex items-center justify-between cursor-pointer"
                    onClick={() => handleViewDetail(run.id)}
                  >
                    <div className="flex items-center gap-3">
                      <span className={`p-1.5 rounded-lg border ${sc.color}`}>{sc.icon}</span>
                      <div>
                        <p className="font-medium text-gray-800">
                          {workflowTypeLabels[run.workflow_type] || run.workflow_type}
                        </p>
                        <p className="text-xs text-gray-400">
                          {run.created_at ? new Date(run.created_at).toLocaleString('zh-CN') : ''}
                          {run.duration_seconds ? ` · ${run.duration_seconds.toFixed(1)}秒` : ''}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`badge ${sc.color.split(' ').slice(1).join(' ')}`}>{sc.label}</span>
                      {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      {detailLoading ? (
                        <div className="text-center py-4 text-gray-400">加载详情中...</div>
                      ) : phases.length > 0 ? (
                        <div className="space-y-2">
                          <p className="text-sm font-medium text-gray-700">执行步骤：</p>
                          {phases.map((phase, i) => (
                            <div key={i} className="flex items-center gap-3 p-2 rounded-lg bg-gray-50">
                              <span className={`w-2 h-2 rounded-full ${
                                phase.status === 'completed' ? 'bg-emerald-500' : 'bg-red-500'
                              }`} />
                              <span className="text-sm text-gray-700 capitalize">
                                {String(phase.phase || '').replace(/_/g, ' ')}
                              </span>
                              {phase.topics_count && (
                                <span className="text-xs text-gray-400">{phase.topics_count} 选题</span>
                              )}
                              {phase.comments_processed && (
                                <span className="text-xs text-gray-400">{phase.comments_processed} 评论</span>
                              )}
                              <span className="ml-auto">
                                {phase.status === 'completed' ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                                ) : (
                                  <XCircle className="w-4 h-4 text-red-500" />
                                )}
                              </span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-gray-400">无详细步骤信息</p>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
