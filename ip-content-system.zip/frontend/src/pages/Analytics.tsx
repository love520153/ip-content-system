import React from 'react';
import {
  BarChart3,
  TrendingUp,
  Users,
  Eye,
  Heart,
  Share2,
  MessageSquare,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell,
  LineChart, Line,
} from 'recharts';

const weeklyData = [
  { name: '周一', 播放量: 1200, 互动量: 85 },
  { name: '周二', 播放量: 1800, 互动量: 120 },
  { name: '周三', 播放量: 1400, 互动量: 95 },
  { name: '周四', 播放量: 2200, 互动量: 160 },
  { name: '周五', 播放量: 2800, 互动量: 210 },
  { name: '周六', 播放量: 3500, 互动量: 280 },
  { name: '周日', 播放量: 2600, 互动量: 190 },
];

const platformData = [
  { name: '抖音', value: 45 },
  { name: 'B站', value: 25 },
  { name: '小红书', value: 20 },
  { name: '微信', value: 10 },
];

const COLORS = ['#3b82f6', '#8b5cf6', '#ec4899', '#10b981'];

const contentPerformance = [
  { type: '短视频', avg播放: 5200, avg互动: 380, 趋势: 'up' },
  { type: '图文', avg播放: 3100, avg互动: 240, 趋势: 'up' },
  { type: '直播', avg观看: 1800, avg互动: 120, 趋势: 'down' },
  { type: '文章', avg阅读: 2200, avg互动: 85, 趋势: 'up' },
];

const kpiCards = [
  { label: '总播放量', value: '15.2万', change: '+28%', icon: Eye, color: 'text-blue-600 bg-blue-50', positive: true },
  { label: '总互动量', value: '1.8万', change: '+35%', icon: Heart, color: 'text-red-600 bg-red-50', positive: true },
  { label: '粉丝增长', value: '3,250', change: '+50%', icon: Users, color: 'text-emerald-600 bg-emerald-50', positive: true },
  { label: '分享率', value: '8.5%', change: '+12%', icon: Share2, color: 'text-purple-600 bg-purple-50', positive: true },
];

export default function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-800">数据分析</h1>
        <p className="text-gray-500 mt-1">多平台内容表现分析与洞察</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {kpiCards.map(({ label, value, change, icon: Icon, color, positive }) => (
          <div key={label} className="stat-card">
            <div className={`p-3 rounded-xl ${color}`}>
              <Icon className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-lg font-bold text-gray-800">{value}</p>
              <p className="text-xs text-gray-500">{label}</p>
              <span className={`inline-flex items-center gap-0.5 text-xs font-medium mt-0.5 ${
                positive ? 'text-emerald-600' : 'text-red-600'
              }`}>
                {positive ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
                {change}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Trend */}
        <div className="card">
          <h3 className="font-semibold text-gray-800 mb-4">本周数据趋势</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" stroke="#9ca3af" fontSize={12} />
              <YAxis stroke="#9ca3af" fontSize={12} />
              <Tooltip />
              <Bar dataKey="播放量" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="互动量" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Platform Distribution */}
        <div className="card">
          <h3 className="font-semibold text-gray-800 mb-4">平台分布</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={platformData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {platformData.map((_, index) => (
                  <Cell key={index} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Content Performance */}
      <div className="card">
        <h3 className="font-semibold text-gray-800 mb-4">内容类型表现</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {contentPerformance.map((item) => (
            <div key={item.type} className="p-4 bg-gray-50 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <p className="font-medium text-gray-800">{item.type}</p>
                <span className={item.趋势 === 'up' ? 'text-emerald-500' : 'text-red-500'}>
                  <TrendingUp className="w-4 h-4" />
                </span>
              </div>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">平均播放</span>
                  <span className="font-medium">{item.avg播放?.toLocaleString() || item.avg观看?.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">平均互动</span>
                  <span className="font-medium">{item.avg互动?.toLocaleString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Section description */}
      <div className="card text-center py-8">
        <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-4" />
        <h3 className="font-semibold text-gray-700 mb-2">更多分析功能即将上线</h3>
        <p className="text-sm text-gray-400">
          包括：单内容深度分析、竞品对比、粉丝画像、最佳发布时间优化
        </p>
      </div>
    </div>
  );
}
