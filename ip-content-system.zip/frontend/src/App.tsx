import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Topics from './pages/Topics';
import ContentStudio from './pages/ContentStudio';
import PlatformPublish from './pages/PlatformPublish';
import WorkflowPage from './pages/Workflow';
import Analytics from './pages/Analytics';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/topics" element={<Topics />} />
        <Route path="/content" element={<ContentStudio />} />
        <Route path="/publish" element={<PlatformPublish />} />
        <Route path="/workflow" element={<WorkflowPage />} />
        <Route path="/analytics" element={<Analytics />} />
      </Route>
    </Routes>
  );
}
